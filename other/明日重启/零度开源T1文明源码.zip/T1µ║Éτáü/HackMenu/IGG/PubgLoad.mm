#import "PubgLoad.h"
#import <UIKit/UIKit.h>
#include <JRMemory/MemScan.h>
#import "JHPP.h"
#import "JHDragView.h"
#import "SCLAlertView.h"
#import "vm_writeData.h"
#import "Config.h"
#import "MBProgressHUD.h"
#import <AdSupport/ASIdentifierManager.h>
#import <sys/stat.h>
#import <dlfcn.h>
#import <stdlib.h>
#import <mach-o/dyld.h>
#import "KeyChainOperrationTool.h"
@interface PubgLoad()

@property (nonatomic, strong) dispatch_source_t timer;
@property (nonatomic,strong) NSDictionary * baseDict;
@property (nonatomic, strong) NSMutableArray *fileArray;
@property (nonatomic,strong) UIAlertController *alertController;
@property (nonatomic,strong) NSString *vertifyString;
@end
@interface PubgLoad()
@end

@implementation PubgLoad
static PubgLoad *extraInfo;
static BOOL MenDeal;

+ (void)load
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
       
    
                               
        extraInfo =  [PubgLoad new];
        [extraInfo Turnonverification];

    });
}


- (void)Turnonverification {// 开启验证 API
    
    //为了完整的流程走完,可以打开一次这个方法编译,来模拟没有安装过描述文件
    //[KeyChainOperrationTool clearIMEI];
    NSMutableDictionary *paramsovm = [NSMutableDictionary dictionary];
    paramsovm[@"api"] = @"BSphpSeSsL.in";//BSphpSeSsL.in
    paramsovm[@"date"] = [self getSystemDate];
    paramsovm[@"md5"] = @"";
    paramsovm[@"mutualkey"] = BSPHP_MUTUALKEY;
    __weak typeof(self) weakself = self;
    [NetTool Post_AppendURL:BSPHP_HOST parameters:paramsovm success:^(id responseObject) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if (!dict) {
            exit(0);
        }
        if (dict) {
            weakself.baseDict = dict;
            [weakself Getversion];
        }
    } failure:^(NSError *error) {
        exit(0);
    }];
}

- (void )Getversion {// 获取版本号 API
    NSMutableDictionary *paramsovm = [NSMutableDictionary dictionary];
    NSString *appsafecode = [self getSystemDate];
    paramsovm[@"api"] = @"v.in";//api=v.in
    paramsovm[@"BSphpSeSsL"] = self.baseDict[@"response"][@"data"];
    paramsovm[@"date"] = [self getSystemDate];
    paramsovm[@"md5"] = @"";
    paramsovm[@"mutualkey"] = BSPHP_MUTUALKEY;
 //   paramsovm[@"currentVersion"] = BSPHP_VERSION;
    paramsovm[@"appsafecode"] = appsafecode;
    [NetTool Post_AppendURL:BSPHP_HOST parameters:paramsovm success:^(id responseObject) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if (dict) {
            if(![dict[@"response"][@"appsafecode"] isEqualToString:appsafecode]){
                exit(0);
            }
            if([dict[@"response"][@"data"]integerValue] > [PubgLoad currentVersion]){
                
                UIAlertController *alertController=[UIAlertController alertControllerWithTitle:@"提示" message:@"版本太低,需要升级新版本" preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *action=[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
                    exit(0);
                }];
                [alertController addAction:action];
                [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertController animated:YES completion:nil];
            }else {
                NSDate *currentDate = [NSDate date];
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                [dateFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
                NSString *date = [dateFormatter stringFromDate:currentDate];
                NSString *saveDate = [[NSUserDefaults standardUserDefaults]valueForKey:@"outDate"];
                if (saveDate && [saveDate compare:date] == NSOrderedDescending) {
                    //NSLog(@"卡密有效期内");
                    [self  yanzhengOldCode  ];
                    return;
                }
                //NSLog(@"卡密无效期外");
                [self  startInputAlert];
            }
        }
    } failure:^(NSError *error) {
        exit(0);
    }];
}

/**对比后台版本号**/
+ (NSInteger)currentVersion {
    return 1;//当前版本号
}

- (void)announcement{//  加载公告 API
    NSMutableDictionary *paramsovm = [NSMutableDictionary dictionary];
    paramsovm[@"api"] = @"gg.in";//gg.in
    paramsovm[@"BSphpSeSsL"] = self.baseDict[@"response"][@"data"];
    paramsovm[@"date"] = [self getSystemDate];
    paramsovm[@"md5"] = @"";
    paramsovm[@"mutualkey"] = BSPHP_MUTUALKEY;
    [NetTool Post_AppendURL:BSPHP_HOST parameters:paramsovm success:^(id responseObject) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if (dict) {
            NSString    *NOTICE= dict[@"response"][@"data"];
            if (NOTICE && NOTICE.length) {
                UIAlertController *alertController=[UIAlertController alertControllerWithTitle:@"公告" message:NOTICE preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction *action=[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
                    
                }];
                [alertController addAction:action];
                [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertController animated:YES completion:nil];
            }
        } else {
        }
    } failure:^(NSError *error) {
        exit(0);
    }];
}

- (void)startInputAlert {
    
    UIAlertController *alertController=[UIAlertController alertControllerWithTitle:@"T1" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"输入购买的卡密";
    }];
    
    UIAlertAction *action=[UIAlertAction actionWithTitle:@"验证" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSString *password = [alertController.textFields firstObject].text;
        [self Verifyrequest:password];
    }];
    
    UIAlertAction *action_cancel=[UIAlertAction actionWithTitle:@"设备" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
        pasteboard.string = [self getIDFA];
        MBProgressHUD *progress = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
        progress.mode = MBProgressHUDModeText;
        progress.label.text = @" 复制设备码成功,请发给相关人员 ";
        [self performSelector:@selector(removehProgress) withObject:nil afterDelay:2.];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self  startInputAlert];
        });
    }];
    
    [alertController addAction:action];
    [alertController addAction:action_cancel];
    self.alertController = alertController;
    
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertController animated:YES completion:nil];
    
}

- (void)Verifyrequest:(NSString *)text {// 验证使用 API
    if (text.length > 0) {
        NSMutableDictionary *paramsovm = [NSMutableDictionary dictionary];
        NSString *appsafecode = [self getSystemDate];
        paramsovm[@"api"] = @"login.ic";//login.ic
        paramsovm[@"BSphpSeSsL"] = self.baseDict[@"response"][@"data"];
        paramsovm[@"date"] = [self getSystemDate];
        paramsovm[@"md5"] = @"";
        paramsovm[@"mutualkey"] = BSPHP_MUTUALKEY;
        paramsovm[@"icid"] = text;
        paramsovm[@"icpwd"] = @"";
        paramsovm[@"key"] = [self getIDFA];
        paramsovm[@"maxoror"] = [self getIDFA];
        paramsovm[@"appsafecode"] = appsafecode;
        [NetTool Post_AppendURL:BSPHP_HOST parameters:paramsovm success:^(id responseObject) {
            NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            if (dict) {
                if(![dict[@"response"][@"appsafecode"] isEqualToString:appsafecode]){
                    exit(0);
                    dict[@"response"][@"data"] = @"-2000";
                    exit(0);
                }
                NSString *dataString = dict[@"response"][@"data"];
                NSRange range = [dataString rangeOfString:@"|1081|"];
                
                if(![dataString containsString:[self getIDFA]]){
                    [self.alertController dismissViewControllerAnimated:YES completion:nil];
                    MBProgressHUD *progress = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
                    progress.mode = MBProgressHUDModeText;
                    progress.label.text = @"授权失败！";
                    [self performSelector:@selector(removehProgress) withObject:nil afterDelay:3.];
                    
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        [self startInputAlert];
                    });
                    return ;
                }
                if (range.location != NSNotFound) {
                    [self.alertController dismissViewControllerAnimated:YES completion:nil];
                    
                    NSRange start = [dataString rangeOfString:@"||"];
                    NSRange end = [dataString rangeOfString:@"|||||"];
                    NSRange range = NSMakeRange(start.location + start.length, end.location - start.location - start.length);
                    NSString *result = [dataString substringWithRange:range];
                    
                    [[NSUserDefaults standardUserDefaults]setValue:result forKey:@"outDate"];
                    [[NSUserDefaults standardUserDefaults]setValue:text forKey:@"oldCode"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    MBProgressHUD *progress = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
                    progress.mode = MBProgressHUDModeText;
                    progress.label.text = [NSString stringWithFormat:@"授权成功,到期时间:%@",result];
                    [self performSelector:@selector(removehProgress) withObject:nil afterDelay:3.5];
                    [self initTapGes];
                    [self tapIconView];

                    
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        [self announcement];
                    });
                }else{
                    MBProgressHUD *progress = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
                    progress.mode = MBProgressHUDModeText;
                    progress.label.text = dataString;
                    [self performSelector:@selector(removehProgress) withObject:nil afterDelay:3.];
                    
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        [self startInputAlert];
                    });
                }
            }
        } failure:^(NSError *error) {
            exit(0);
        }];
    }else{
        MBProgressHUD *progress = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
        progress.mode = MBProgressHUDModeText;
        progress.label.text = @"请输入授权码";
        [self performSelector:@selector(removehProgress) withObject:nil afterDelay:3.];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self startInputAlert];
        });
    }
}

- (void)yanzhengOldCode{// 判断是否验证
    NSString *text  = [[NSUserDefaults standardUserDefaults ]valueForKey:@"oldCode"];
    if (text && text.length > 0) {
        NSMutableDictionary *paramsovm = [NSMutableDictionary dictionary];
        NSString *appsafecode = [self getSystemDate];
        paramsovm[@"api"] = @"login.ic";//login.ic
        paramsovm[@"BSphpSeSsL"] = self.baseDict[@"response"][@"data"];
        paramsovm[@"date"] = [self getSystemDate];
        paramsovm[@"md5"] = @"";
        paramsovm[@"mutualkey"] = BSPHP_MUTUALKEY;
        paramsovm[@"icid"] = text;
        paramsovm[@"icpwd"] = @"";
        paramsovm[@"key"] = [self getIDFA];
        paramsovm[@"maxoror"] = [self getIDFA];
        paramsovm[@"appsafecode"] = appsafecode;
        [NetTool Post_AppendURL:BSPHP_HOST parameters:paramsovm success:^(id responseObject) {
            NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            if (dict) {
                if(![dict[@"response"][@"appsafecode"] isEqualToString:appsafecode]){
                    exit(0);
                    dict[@"response"][@"data"] = @"-2000";
                    exit(0);
                }
                NSString *dataString = dict[@"response"][@"data"];
                NSRange range = [dataString rangeOfString:@"|1081|"];
                if(![dataString containsString:[self getIDFA]]){
                    [self.alertController dismissViewControllerAnimated:YES completion:nil];
                    [self startInputAlert];
                    return ;
                }
                if (range.location != NSNotFound) {
                    [self.alertController dismissViewControllerAnimated:YES completion:nil];
                    NSRange start = [dataString rangeOfString:@"||"];
                    NSRange end = [dataString rangeOfString:@"|||||"];
                    NSRange range = NSMakeRange(start.location + start.length, end.location - start.location - start.length);
                    NSString *result = [dataString substringWithRange:range];
                    [[NSUserDefaults standardUserDefaults]setValue:result forKey:@"outDate"];
                    [[NSUserDefaults standardUserDefaults]setValue:text forKey:@"oldCode"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    
                    MBProgressHUD *progress = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
                    progress.mode = MBProgressHUDModeText;
                    progress.label.text = [NSString stringWithFormat:@"到期时间:%@",result];
                    [self performSelector:@selector(removehProgress) withObject:nil afterDelay:3.5];
                    
                    [self initTapGes];
                    [self tapIconView];

                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        [self announcement];
                    });
                }else{
                    [self startInputAlert];
                }
            }
        } failure:^(NSError *error) {
            exit(0);
        }];
    }else{
        [self startInputAlert];
    }
}

-(void)removehProgress{
    [MBProgressHUD hideHUDForView:[UIApplication sharedApplication].keyWindow animated:YES];
}

- (NSString *)getSystemDate{
    NSDate *currentDate = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY/MM/dd#HH:mm:ss"];
    return [dateFormatter stringFromDate:currentDate];
}

-(NSString *)getIDFA{
    NSString * IDFA = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
    return IDFA;
}



-(void)initTapGes

{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    tap.numberOfTapsRequired = 3;//点击次数
    tap.numberOfTouchesRequired = 3;//手指数
    [[JHPP currentViewController].view addGestureRecognizer:tap];
    [tap addTarget:self action:@selector(tapIconView)];
}

-(void)tapIconView
{
    JHDragView *view = [[UIApplication sharedApplication].keyWindow viewWithTag:100];
    if (!view) {
        view = [[JHDragView alloc] init];
        view.tag = 100;
        [[JHPP currentViewController].view addSubview:view];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onConsoleButtonTapped:)];
        tap.numberOfTapsRequired = 1;
        [view addGestureRecognizer:tap];
    }
    
    if (!MenDeal) {
        view.hidden = NO;
    } else {
        view.hidden = YES;
    }
    
    MenDeal = !MenDeal;
}


/*------------------------------------------------------------------------*/

#pragma mark  菜单入口


-(void)onConsoleButtonTapped:(id)sender{
        SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
    [alert addTimerToButtonIndex:0 reverse:YES];

    [alert addButton:@"💯开启防封💯" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x250000000};
            float search = 67109633;
            engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
            vector<void*>results = engine.getAllResults();
            float modify = 67109634;
            for(int i = 0; i < results.size(); i++){
                    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);}
            });
        }];
    
    [alert addButton:@"✈️滑翔翼用户专用飞天✈️" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x250000000};
            float search = 1.0400390625;
            engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
            vector<void*>results = engine.getAllResults();
            float modify = -480;
            for(int i = 0; i < results.size(); i++){
                    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);}
            });
        }];
    
    

    [alert addButton:@"天线范围" actionBlock:^{
       dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)),
       dispatch_get_main_queue(), ^{
       [self fanwei];});
       }];
    
    [alert addButton:@"武器功能" actionBlock:^{
       dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)),
       dispatch_get_main_queue(), ^{
       [self wuqi];});
       }];
    
//    [alert addButton:@"飞天功能" actionBlock:^{
//       dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)),
//       dispatch_get_main_queue(), ^{
//       [self feitian];});
//       }];
    
    [alert addButton:@"常用功能" actionBlock:^{
       dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)),
       dispatch_get_main_queue(), ^{
       [self changyong];});
       }];
    
    [alert addButton:@"其他功能" actionBlock:^{
       dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)),
       dispatch_get_main_queue(), ^{
       [self qita];});
       }];
    
        alert.shouldDismissOnTapOutside = YES;
       [alert showSuccess:@"文明重启T1辅助工具" subTitle:@"欢迎使用T1-2.4版本\n祝您游戏愉快" closeButtonTitle:nil duration:0];
    }

#pragma mark  二级菜单
//天线范围
-(void)fanwei{
    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
       [alert addTimerToButtonIndex:0 reverse:YES];
   
    [alert addButton:@"循环天线" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x240000000};
        float search = 0.16947640479;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = -9999;
        for(int i = 0;i<results.size();i++){
            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
                }
        });     }];
    
    [alert addButton:@"棒槌天线" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x130000000,0x240000000};
        float search = -0.9855342507362366;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = -9999;
        for(int i = 0;i<results.size();i++){
            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
                }
        });     }];
    
    [alert addButton:@"0.6小范围" actionBlock:^{
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
         JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
         AddrRange range = (AddrRange){0x250000000,0x290000000};
         float search = 0.16;
         engine.JRScanMemory(range, &search, JR_Search_Type_Float);
         vector<void*>results = engine.getAllResults();
         float modify = 0.6;
         for(int i = 0;i<results.size();i++){
             engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
                 }
         });     }];
    
    [alert addButton:@"1.2中范围" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x250000000,0x290000000};
        float search = 0.16;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 1.2;
        for(int i = 0;i<results.size();i++){
            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
                }
        });     }];
    
    [alert addButton:@"2.0大范围" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x250000000,0x290000000};
        float search = 0.16;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 2.0;
        for(int i = 0;i<results.size();i++){
            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
                }
        });     }];
    alert.shouldDismissOnTapOutside = YES;
    [alert showSuccess:@"文明重启范围工具" subTitle:@"欢迎使用T1\n祝您游戏愉快" closeButtonTitle:nil duration:0];
}

//武器功能
-(void)wuqi{
    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
       [alert addTimerToButtonIndex:0 reverse:YES];
   
    [alert addButton:@"无后专区" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)),
    dispatch_get_main_queue(), ^{
    [self wuhou];});
    }];
    [alert addButton:@"聚点专区" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)),
    dispatch_get_main_queue(), ^{
    [self judian];});
    }];
    [alert addButton:@"秒换专区" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)),
    dispatch_get_main_queue(), ^{
    [self miaohuan];});
    }];
    [alert addButton:@"瞬击专区" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)),
    dispatch_get_main_queue(), ^{
    [self shunji];});
    }];
    [alert addButton:@"瞬爆专区" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)),
    dispatch_get_main_queue(), ^{
    [self shunbao];});
    }];
    alert.shouldDismissOnTapOutside = YES;
    [alert showSuccess:@"文明重启武器工具" subTitle:@"欢迎使用T1\n祝您游戏愉快" closeButtonTitle:nil duration:0];
}
//
////飞天功能
//-(void)feitian{
//    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
//       [alert addTimerToButtonIndex:0 reverse:YES];
//
//    [alert addButton:@"飞天50米-开" actionBlock:^{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//        AddrRange range = (AddrRange){0x130000000,0x175000000};
//        float search = 10;
//        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
//        vector<void*>results = engine.getAllResults();
//        float modify = 50;
//        for(int i =0;i<results.size();i++){
//            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
//            }
//        });     }];
//    [alert addButton:@"飞天50米-关" actionBlock:^{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//        AddrRange range = (AddrRange){0x130000000,0x175000000};
//        float search = 50;
//        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
//        vector<void*>results = engine.getAllResults();
//        float modify = 10;
//        for(int i =0;i<results.size();i++){
//            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
//            }
//        });     }];
//
//    [alert addButton:@"飞天100米-开" actionBlock:^{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//        AddrRange range = (AddrRange){0x130000000,0x175000000};
//        float search = 10;
//        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
//        vector<void*>results = engine.getAllResults();
//        float modify = 100;
//        for(int i =0;i<results.size();i++){
//            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
//            }
//        });     }];
//    [alert addButton:@"飞天100米-关" actionBlock:^{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//        AddrRange range = (AddrRange){0x130000000,0x175000000};
//        float search = 100;
//        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
//        vector<void*>results = engine.getAllResults();
//        float modify = 10;
//        for(int i =0;i<results.size();i++){
//            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
//            }
//        });     }];
//
//    [alert addButton:@"飞天200米-开" actionBlock:^{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//        AddrRange range = (AddrRange){0x130000000,0x175000000};
//        float search = 10;
//        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
//        vector<void*>results = engine.getAllResults();
//        float modify = 200;
//        for(int i =0;i<results.size();i++){
//            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
//            }
//        });     }];
//    [alert addButton:@"飞天200米-关" actionBlock:^{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//        AddrRange range = (AddrRange){0x130000000,0x175000000};
//        float search = 200;
//        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
//        vector<void*>results = engine.getAllResults();
//        float modify = 10;
//        for(int i =0;i<results.size();i++){
//            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
//            }
//        });     }];
//
//    [alert addButton:@"飞天400米-开" actionBlock:^{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//        AddrRange range = (AddrRange){0x130000000,0x175000000};
//        float search = 10;
//        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
//        vector<void*>results = engine.getAllResults();
//        float modify = 400;
//        for(int i =0;i<results.size();i++){
//            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
//            }
//        });     }];
//    [alert addButton:@"飞天400米-关" actionBlock:^{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//        AddrRange range = (AddrRange){0x130000000,0x175000000};
//        float search = 400;
//        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
//        vector<void*>results = engine.getAllResults();
//        float modify = 10;
//        for(int i =0;i<results.size();i++){
//            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
//            }
//        });     }];
//
//    alert.shouldDismissOnTapOutside = YES;
//    [alert showSuccess:@"文明重启飞天工具" subTitle:@"欢迎使用T1\n祝您游戏愉快" closeButtonTitle:nil duration:0];
//}

//常用功能
-(void)changyong{
    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
       [alert addTimerToButtonIndex:0 reverse:YES];
   
    [alert addButton:@"强制建筑" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x200000000};
        uint64_t search = 1125899906842625;
        engine.JRScanMemory(range, &search, JR_Search_Type_ULong);
        uint64_t search1 = 4503600701112320;
        engine.JRNearBySearch(0x60,&search1,JR_Search_Type_ULong);
        uint64_t search2 = 1125899906842625;
        engine.JRScanMemory(range, &search2,JR_Search_Type_ULong);
        vector<void*>results = engine.getAllResults();
        uint64_t modify = -999;
        for(int i =0;i<results.size();i++){
            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_ULong);
        }
        });     }];
    
    [alert addButton:@"假死无脚步" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x200000000};
        float search = 2.3057977e-38;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 2.79703205e-33;
        for(int i =0;i<results.size();i++){
            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
        }
        });     }];
    
    [alert addButton:@"假死无脚步-2" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,200000000};
        float search = 1.33704298e23;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 2.79703205e-33;
        for(int i =0;i<results.size();i++){
            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
        }
        });     }];
    
    [alert addButton:@"人物半遁" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
          AddrRange range = (AddrRange){0x100000000,0x500000000};
            uint32_t search = 1065689088;
            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
            vector<void*>results = engine.getAllResults();
            uint32_t modify = 1073722337;
            for(int i =0;i<results.size();i++){
                engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_UInt);
                 }
        });     }];
    
    
    
    [alert addButton:@"机瞄八倍" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x200000000};
        float search = 48;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        float Nearsearch = 1.401298e-45;
        engine.JRNearBySearch(0x50,&Nearsearch,JR_Search_Type_Float);
        float search1 = 48;
        engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 10;
        for(int i =0;i<results.size();i++){
            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
            }
        });     }];
    
    [alert addButton:@"地基封人" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x200000000};
        float search = 54.394535064697266;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 0;
        for(int i =0;i<results.size();i++){
            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
        }
        });     }];
    [alert addButton:@"昼夜交替" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x200000000};
        float search = 0.0067;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        float search1 = 9.21942e-41;
        engine.JRNearBySearch(0x60,&search1,JR_Search_Type_Float);
        float search2 = 9.21942e-41;
        engine.JRScanMemory(range, &search2,JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = -999;
        for(int i =0;i<results.size();i++){
            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
        }
        });     }];
    [alert addButton:@"第三人称视角" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x270000000};
        float search = 1.70000004768;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 5;
        for(int i =0;i<results.size();i++){
            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
            }
        });     }];
    [alert addButton:@"水下行走" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x200000000};
        float search = 0.00999999978;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        float search1 = 10000;
        engine.JRNearBySearch(0x100, &search1, JR_Search_Type_Float);
        float search2 = 10000;
        engine.JRScanMemory(range, &search2, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 0;
        for(int i =0;i<results.size();i++){
            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
            }
        });     }];
    
    alert.shouldDismissOnTapOutside = YES;
    [alert showSuccess:@"文明重启常用工具" subTitle:@"欢迎使用T1\n祝您游戏愉快" closeButtonTitle:nil duration:0];
}

//其他功能
-(void)qita{
    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
       [alert addTimerToButtonIndex:0 reverse:YES];
   
    [alert addButton:@"灵魂穿墙-开" actionBlock:^{
      dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
          JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
          AddrRange range = (AddrRange){0x100000000,0x200000000};
          float search = 1.0e32;
          engine.JRScanMemory(range, &search, JR_Search_Type_Float);
          float Nearsearch = 0.005;
          engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
          float search1 = 1.0e32;
          engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
          vector<void*>results = engine.getAllResults();
          float modify = 8.8888;
          for(int i =0;i<results.size();i++){
              engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
              }
          });     }];
    [alert addButton:@"灵魂穿墙-关" actionBlock:^{
      dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
          JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
          AddrRange range = (AddrRange){0x100000000,0x200000000};
          float search = 8.8888;
          engine.JRScanMemory(range, &search, JR_Search_Type_Float);
          vector<void*>results = engine.getAllResults();
          float modify = 1.0e32;
          for(int i =0;i<results.size();i++){
              engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
              }
          });     }];
    [alert addButton:@"子弹穿图-关闭重进" actionBlock:^{
      dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
          JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
          AddrRange range = (AddrRange){0x100000000,0x200000000};
          float search = 1.401298e-41;
          engine.JRScanMemory(range, &search, JR_Search_Type_Float);
          float search1 = 1.401298e-43;
          engine.JRNearBySearch(0x60,&search1,JR_Search_Type_Float);
          float search2 = 1.401298e-41;
          engine.JRScanMemory(range, &search2,JR_Search_Type_Float);
          vector<void*>results = engine.getAllResults();
          float modify = 0;
          for(int i =0;i<results.size();i++){
              engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
          }
          });     }];
    [alert addButton:@"全图定怪" actionBlock:^{
      dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
          JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
          AddrRange range = (AddrRange){0x100000000,0x300000000};
          float  search1 = 18;
          engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
          float search2 = 272;
          engine.JRNearBySearch(0x50,&search2,JR_Search_Type_Float);
          float search3 = 0.1;
          engine.JRScanMemory(range, &search3, JR_Search_Type_Float);
          vector<void*>results = engine.getAllResults();
          float  modify = 999;
          for(int i =0;i<results.size();i++){
              engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
               }
          });     }];
    
    [alert addButton:@"人物高跳" actionBlock:^{
      dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
          JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
          AddrRange range = (AddrRange){0x100000000,0x160000000};
          float search = 1.03999996185;
          engine.JRScanMemory(range, &search, JR_Search_Type_Float);
          vector<void*>results = engine.getAllResults();
          float modify = -300;
          for(int i =0;i<results.size();i++){
          engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
              }
          });     }];
    
    [alert addButton:@"陷入遁地-开" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x160000000};
        float search = -1.0e32;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 0.1179953374;
        for(int i =0;i<results.size();i++){
        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
            }
        });     }];
    
    [alert addButton:@"陷入遁地-关" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x160000000};
        float search = 0.1179953374;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = -1.0e32;
        for(int i =0;i<results.size();i++){
        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
            }
        });     }];

    
    alert.shouldDismissOnTapOutside = YES;
    [alert showSuccess:@"文明重启其他工具" subTitle:@"欢迎使用T1\n祝您游戏愉快" closeButtonTitle:nil duration:0];
}
    

#pragma mark  三级菜单
//无后专区
-(void)wuhou{
    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
       [alert addTimerToButtonIndex:0 reverse:YES];
   
    [alert addButton:@"SMG无后" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
         AddrRange range = (AddrRange){0x100000000,0x200000000};
         float search1 = 15;
         engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
         float search2 = 4;
         engine.JRNearBySearch(0x100, &search2, JR_Search_Type_Float);
         float search3 = 4;
         engine.JRNearBySearch(0x100, &search3, JR_Search_Type_Float);
         float search4 = 4;
         engine.JRScanMemory(range, &search4, JR_Search_Type_Float);
         vector<void*>results = engine.getAllResults();
         float modify = 0;
         for(int i =0;i<results.size();i++){
             engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
                }
        });     }];
    
    [alert addButton:@"UZI无后" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
         AddrRange range = (AddrRange){0x100000000,0x200000000};
         float search1 = 16;
         engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
         float search2 = 4;
         engine.JRNearBySearch(0x100, &search2, JR_Search_Type_Float);
         float search3 = 4;
         engine.JRNearBySearch(0x100, &search3, JR_Search_Type_Float);
         float search4 = 4;
         engine.JRScanMemory(range, &search4, JR_Search_Type_Float);
         vector<void*>results = engine.getAllResults();
         float modify = 0;
         for(int i =0;i<results.size();i++){
             engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
                 }
        });     }];
    
    [alert addButton:@"M4/QBZ无后" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
         AddrRange range = (AddrRange){0x100000000,0x200000000};
         float search1 = 12;
         engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
         float search2 = 4;
         engine.JRNearBySearch(0x100, &search2, JR_Search_Type_Float);
         float search3 = 4;
         engine.JRNearBySearch(0x100, &search3, JR_Search_Type_Float);
         float search4 = 4;
         engine.JRScanMemory(range, &search4, JR_Search_Type_Float);
         vector<void*>results = engine.getAllResults();
         float modify = 0;
         for(int i =0;i<results.size();i++){
             engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
                 }
        });     }];
    
    [alert addButton:@"AK无后" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
         AddrRange range = (AddrRange){0x100000000,0x200000000};
         float search1 = 14;
         engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
         float search2 = 4;
         engine.JRNearBySearch(0x100, &search2, JR_Search_Type_Float);
         float search3 = 4;
         engine.JRNearBySearch(0x100, &search3, JR_Search_Type_Float);
         float search4 = 4;
         engine.JRScanMemory(range, &search4, JR_Search_Type_Float);
         vector<void*>results = engine.getAllResults();
         float modify = 0;
         for(int i =0;i<results.size();i++){
             engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
                }
        });     }];
    alert.shouldDismissOnTapOutside = YES;
    [alert showSuccess:@"文明重启无后工具" subTitle:@"欢迎使用T1\n祝您游戏愉快" closeButtonTitle:nil duration:0];
}

//聚点专区
-(void)judian{
    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
       [alert addTimerToButtonIndex:0 reverse:YES];
   
    [alert addButton:@"SMG/FAMAS聚点" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
         AddrRange range = (AddrRange){0x100000000,0x290000000};
         float search = 3;
         engine.JRScanMemory(range, &search, JR_Search_Type_Float);
         float Nearsearch = 2.5;
         engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
         vector<void*>results = engine.getAllResults();
         float modify = 0;
         for(int i =0;i<results.size();i++){
             engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
             }
        });     }];
    
    [alert addButton:@"UZI聚点" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
         AddrRange range = (AddrRange){0x100000000,0x200000000};
         float search = 16;
         engine.JRScanMemory(range, &search, JR_Search_Type_Float);
         float Nearsearch = 2;
         engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
         float Nearsearch1 = 3;
         engine.JRNearBySearch(0x10,&Nearsearch1,JR_Search_Type_Float);
         vector<void*>results = engine.getAllResults();
         float modify = 0;
         for(int i =0;i<results.size();i++){
             engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
            }
        });     }];
    
    [alert addButton:@"QBZ/M4聚点" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
         AddrRange range = (AddrRange){0x100000000,0x290000000};
         float search = 6;
         engine.JRScanMemory(range, &search, JR_Search_Type_Float);
         float Nearsearch = 3.5;
         engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
         vector<void*>results = engine.getAllResults();
         float modify = 0;
         for(int i =0;i<results.size();i++){
             engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
             }
        });     }];
    
    [alert addButton:@"AK/762聚点" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x200000000};
         float search1 = 14;
         engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
         float search2 = 6;
         engine.JRNearBySearch(0x100, &search2, JR_Search_Type_Float);
         float search3 = 6;
         engine.JRNearBySearch(0x100, &search3, JR_Search_Type_Float);
         float search4 = 6;
         engine.JRScanMemory(range, &search4, JR_Search_Type_Float);
         vector<void*>results = engine.getAllResults();
         float modify = 0;
         for(int i =0;i<results.size();i++){
             engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
             }
        });     }];
    alert.shouldDismissOnTapOutside = YES;
    [alert showSuccess:@"文明重启聚点工具" subTitle:@"欢迎使用T1\n祝您游戏愉快" closeButtonTitle:nil duration:0];
}

//秒换专区
-(void)miaohuan{
    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
       [alert addTimerToButtonIndex:0 reverse:YES];
   
//    [alert addButton:@"SMG秒换" actionBlock:^{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//        AddrRange range = (AddrRange){0x100000000,0x160000000};
//        uint32_t search = 1076538027;
//        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
//        vector<void*>results = engine.getAllResults();
//        uint32_t modify = 953267991;
//        for(int i =0;i<results.size();i++){
//                   engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_UInt);
//               }
//        });     }];
//
//    [alert addButton:@"UZI秒换" actionBlock:^{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//        AddrRange range = (AddrRange){0x100000000,0x160000000};
//        uint32_t search = 1077237078;
//        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
//        vector<void*>results = engine.getAllResults();
//        uint32_t modify = 1077237078;
//        for(int i =0;i<results.size();i++){
//                   engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_UInt);
//               }
//        });     }];
//
//    [alert addButton:@"QBZ秒换" actionBlock:^{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//        AddrRange range = (AddrRange){0x120000000,0x170000000};
//        float search = 2.16666674614;
//        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
//        vector<void*>results = engine.getAllResults();
//        float modify = 0.0001;
//        for(int i =0;i<results.size();i++){
//            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
//            }
//        });     }];
//
//    [alert addButton:@"M4秒换" actionBlock:^{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//        AddrRange range = (AddrRange){0x100000000,0x160000000};
//        uint32_t search = 1074440875;
//        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
//        vector<void*>results = engine.getAllResults();
//        uint32_t modify = 953267991;
//        for(int i =0;i<results.size();i++){
//                   engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_UInt);
//               }
//        });     }];
//
//    [alert addButton:@"AK秒换" actionBlock:^{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//        AddrRange range = (AddrRange){0x120000000,0x170000000};
//        uint32_t search = 1076538027;//f32搜索 0.05499718338
//        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
//        vector<void*>results = engine.getAllResults();
//        uint32_t modify = 1036831949;
//        for(int i =0;i<results.size();i++){
//            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_UInt);
//        }
//        });     }];
    [alert addButton:@"SMG秒换-手动" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x120000000,0x170000000};
        float search = 2;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 0.001;
        for(int i =0;i<results.size();i++){
        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
        }
        });     }];
    
    [alert addButton:@"SMG秒换-自动" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x120000000,0x170000000};
        float search = 2.66666674614;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 0.001;
        for(int i =0;i<results.size();i++){
        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
        }
        });     }];
    
    [alert addButton:@"UZI秒换-手	动" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x120000000,0x170000000};
        float search = 2.83333349228;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 0.001;
        for(int i =0;i<results.size();i++){
        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
        }
        });     }];
    
    [alert addButton:@"FAMAS秒换-手动" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x120000000,0x170000000};
        float search = 2.76666688919;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 0.001;
        for(int i =0;i<results.size();i++){
        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
        }
        });     }];
    
    [alert addButton:@"QBZ秒换-手动" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x120000000,0x170000000};
        float search = 2.03333353996;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 0.001;
        for(int i =0;i<results.size();i++){
        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
        }
        });     }];
    
    [alert addButton:@"QBZ秒换-自动" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x120000000,0x170000000};
        float search = 2.90000009537;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 0.001;
        for(int i =0;i<results.size();i++){
        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
        }
        });     }];
    
    [alert addButton:@"M4/AK秒换-手动" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x120000000,0x170000000};
        float search = 2.16666674614;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 0.001;
        for(int i =0;i<results.size();i++){
        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
        }
        });     }];
    
    [alert addButton:@"M4/AK秒换-自动" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x120000000,0x170000000};
        float search = 2.66666674614;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 0.001;
        for(int i =0;i<results.size();i++){
        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
        }
        });     }];
    	
    alert.shouldDismissOnTapOutside = YES;
    [alert showSuccess:@"文明重启秒换工具" subTitle:@"欢迎使用T1\n祝您游戏愉快" closeButtonTitle:nil duration:0];
}

//瞬击专区
-(void)shunji{
    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
       [alert addTimerToButtonIndex:0 reverse:YES];
   
    [alert addButton:@"SMG瞬击" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x160000000};
        uint32_t search = 1133903872;
        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
        vector<void*>results = engine.getAllResults();
        uint32_t modify = 1203982208;
        for(int i =0;i<results.size();i++){
            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_UInt);
        }
        });     }];
    
    [alert addButton:@"FAMAS瞬击" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x160000000};
        float search = 360;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        float Nearsearch = 1;
        engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
        float search1 = 360;
        engine.JRNearBySearch(0x10,&search1,JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 9999;
        for(int i =0;i<results.size();i++){
            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
            }
        });     }];
    
    [alert addButton:@"M4瞬击" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x160000000};
        uint32_t search = 1146060800;
        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
        vector<void*>results = engine.getAllResults();
        uint32_t modify = 1203982208;
        for(int i =0;i<results.size();i++){
            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_UInt);
            }
        });     }];
    alert.shouldDismissOnTapOutside = YES;
    [alert showSuccess:@"文明重启瞬击工具" subTitle:@"欢迎使用T1\n祝您游戏愉快" closeButtonTitle:nil duration:0];
}

//瞬爆专区
-(void)shunbao{
    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
       [alert addTimerToButtonIndex:0 reverse:YES];
   
    [alert addButton:@"RPG瞬爆" actionBlock:^{
       dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
           JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
           AddrRange range = (AddrRange){0x100000000,0x160000000};
           float search = 3;
           engine.JRScanMemory(range, &search, JR_Search_Type_Float);
           float Nearsearch = 35;
           engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
           float Nearsearch1 = 20;
           engine.JRNearBySearch(0x100,&Nearsearch1,JR_Search_Type_Float);
           vector<void*>results = engine.getAllResults();
           float modify = 0;
           for(int i =0;i<results.size();i++){
               engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
           }
           float Nearsearch2 = 40;
           engine.JRNearBySearch(0x100,&Nearsearch2,JR_Search_Type_Float);
           float search1 = 40;
           engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
           vector<void*>results1 = engine.getAllResults();
           float modify1 = 99999;
           for(int i =0;i<results.size();i++){
               engine.JRWriteMemory((unsigned long long)(results1[i]),&modify1,JR_Search_Type_Float);
               }
           });     }];
    
    [alert addButton:@"榴弹瞬爆" actionBlock:^{
       dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
           JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
           AddrRange range = (AddrRange){0x100000000,0x160000000};
           uint64_t search = 4728779609789274522;
           engine.JRScanMemory(range, &search, JR_Search_Type_SLong);
           vector<void*>results = engine.getAllResults();
           uint64_t modify = 1050253722;
           for(int i =0;i<results.size();i++){
               engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SLong);
           }
           float Nearsearch2 = 25;
           engine.JRNearBySearch(0x100,&Nearsearch2,JR_Search_Type_Float);
           float search2 = 25;
           engine.JRScanMemory(range, &search2, JR_Search_Type_Float);
           vector<void*>results1 = engine.getAllResults();
           float modify1 = 99999;
           for(int i =0;i<results.size();i++){
               engine.JRWriteMemory((unsigned long long)(results1[i]),&modify1,JR_Search_Type_Float);
               }
           });     }];
    alert.shouldDismissOnTapOutside = YES;
    [alert showSuccess:@"文明重启瞬爆工具" subTitle:@"欢迎使用T1\n祝您游戏愉快" closeButtonTitle:nil duration:0];
}





#pragma mark  提示条
-(void)showMessage:(NSString *)message duration:(NSTimeInterval)time
{
    CGSize screenSize = [[UIScreen mainScreen] bounds].size;
    
    UIWindow * window = [UIApplication sharedApplication].keyWindow;
    UIView *showview =  [[UIView alloc]init];
    showview.backgroundColor = [UIColor whiteColor];
    showview.frame = CGRectMake(1, 1, 1, 1);
    showview.alpha = 1.0f;
    showview.layer.cornerRadius = 5.0f;
    showview.layer.masksToBounds = YES;
    [window addSubview:showview];
    
    UILabel *label = [[UILabel alloc]init];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    
    NSDictionary *attributes = @{NSFontAttributeName:[UIFont systemFontOfSize:15.f],
                                 NSParagraphStyleAttributeName:paragraphStyle.copy};
    
    CGSize labelSize = [message boundingRectWithSize:CGSizeMake(207, 999)
                                             options:NSStringDrawingUsesLineFragmentOrigin
                                          attributes:attributes context:nil].size;
    
    label.frame = CGRectMake(10, 5, labelSize.width +20, labelSize.height);
    label.text = message;
    label.textColor = [UIColor blackColor];
//    label.textAlignment = 1;
    label.backgroundColor = [UIColor whiteColor];
    label.font = [UIFont boldSystemFontOfSize:15];
    [showview addSubview:label];
    
    showview.frame = CGRectMake((screenSize.width - labelSize.width - 20)/2,
                                screenSize.height - 300,
                                labelSize.width+40,
                                labelSize.height+10);
    [UIView animateWithDuration:time animations:^{
        showview.alpha = 0;
    } completion:^(BOOL finished) {
        [showview removeFromSuperview];
    }];
}

@end
