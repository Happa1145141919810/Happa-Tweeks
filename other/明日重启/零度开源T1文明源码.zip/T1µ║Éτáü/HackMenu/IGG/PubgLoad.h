//
//  PubgLoad.h
//  pubg
//
//  Created by 李良林 on 2021/2/14.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PubgLoad : NSObject
//服务器地址
#define BSPHP_HOST  @"http://121.62.63.152:88/AppEn.php?appid=123456&m=11e1070d9b675ca0c908deaca19af651"

//通信认证key
#define BSPHP_MUTUALKEY @"ea84b63ff9e71fba3fbf47e4c245a3e1"

//数据加密密码
#define BSPHP_PASSWORD @"43Vb2ZX6FiguMdX9uI"

//接收Sgin验证
#define BSPHP_INSGIN @"[KEY]sf1234554321"

//输出Sgin验证
#define BSPHP_TOSGIN @"[KEY]sf1234554321"

//#define BSPHP_VERSION @"v1.0"

#define FDFDDFGDGH4556652pdsjagjhsdqa15465234 @"1"




@end

NS_ASSUME_NONNULL_END
