
/**
 *  BSPHP网络验证系统 OC演示案例
 *  官方网站 Bsphp.com
 *  BSPHP 技术团队触屏
 *  下面是全局配置信息
 *  有技术上问题可以加群讨论 技术QQ群:204422843
 *
 *  2019 bsphp-pro
 */

#import <Foundation/Foundation.h>

@interface NetTool : NSObject

/**
 *  AFN异步发送post请求，返回原生数据
 *
 *  @param appendURL 追加URL
 *  @param param     参数字典
 *  @param success   成功Block
 *  @param failure   失败Block
 *
 *  @return NSURLSessionDataTask任务类型
 */
+ (NSURLSessionDataTask *)Post_AppendURL:(NSString *)appendURL parameters:(NSDictionary *)param success:(void (^)(id responseObject))success failure:(void (^)(NSError *error))failure;
@end
