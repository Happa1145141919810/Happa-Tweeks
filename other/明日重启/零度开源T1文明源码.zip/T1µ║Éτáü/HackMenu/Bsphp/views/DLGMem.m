//
//  DLGMem.m
//  memui
//
//  Created by Liu Junqi on 4/23/18.
//  Copyright © 2018 DeviLeo. All rights reserved.
//

#import "DLGMem.h"
#import "DLGMemUI.h"
#import "DLGMemUIView.h"
//#include "mem.h"
#import <UIKit/UIKit.h>
#import "UIView+Toast.h"


@interface DLGMem () <DLGMemUIViewDelegate> {
    mach_port_t g_task;
    
    int g_type;
}

@property (nonatomic, weak) DLGMemUIView *memView;

@end

@implementation DLGMem

- (instancetype)init {
    self = [super init];
    if (self) {
        [self initVars];
    }
    return self;
}

- (void)dealloc {
    NSLog(@"%@ dealloc", self);
}

- (void)initVars {
    
   
}

- (void)launchDLGMem {
    [DLGMemUI addDLGMemUIView:self];
}

- (void)nearMemSearch:(const char*)value type:(int)type range:(int)range{
   
}





- (void)searchMem:(const char *)value type:(int)type comparison:(int)comparison {
    
}






#pragma mark - DLGMemUIViewDelegate
- (void)DLGMemUILaunched:(DLGMemUIView *)view {
    self.memView = view;
}

@end
