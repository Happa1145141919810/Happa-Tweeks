//
//  UIView+UIViewVC.h
//  libhackor
//
//  Created by zm z on 2018/10/12.
//  Copyright © 2018年 DeviLeo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (UIViewVC)

-(UIViewController *)getCurrentViewController;

@end
