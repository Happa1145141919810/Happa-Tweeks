//
//  PubgLoad.h
//  pubg
//
//  Created by 零度 on 2021/2/14.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PubgLoad : NSObject
//服务器地址
#define BSPHP_HOST @"http://121.62.63.5:88/AppEn.php?appid=20000124&m=b98a946173efacf931398365701b3889"

//通信认证key
#define BSPHP_MUTUALKEY @"09250c04e30c3746b87a69d8d5da5cf5"

//数据加密密码
#define BSPHP_PASSWORD @"rr4h9gU8IFMWd1CY5i"

//接收Sgin验证
#define BSPHP_INSGIN @"[key]2022NPC"

//输出Sgin验证
#define BSPHP_TOSGIN @"[key]2022NPC"

//检测当前版本
#define BSPHP_VERSION @"1"

//检测当前版本2
#define FDFDDFGDGH4556652pdsjagjhsdqa15465234 @"1"


@end

NS_ASSUME_NONNULL_END
