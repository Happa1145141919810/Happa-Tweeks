#import "PubgLoad.h"
#import <UIKit/UIKit.h>
#include <JRMemory/MemScan.h>
#import "JHPP.h"
#import "JHDragView.h"
#import "SCLAlertView.h"
#import "vm_writeData.h"
#import "Config.h"
#import "MBProgressHUD.h"
#import <AdSupport/ASIdentifierManager.h>
#import <sys/stat.h>
#import <dlfcn.h>
#import <stdlib.h>
#import <mach-o/dyld.h>
#import "KeyChainOperrationTool.h"
@interface PubgLoad()

@property (nonatomic, strong) dispatch_source_t timer;
@property (nonatomic,strong) NSDictionary * baseDict;
@property (nonatomic, strong) NSMutableArray *fileArray;
@property (nonatomic,strong) UIAlertController *alertController;
@property (nonatomic,strong) NSString *vertifyString;
@property (nonatomic, assign) vector<void*> dundi3;
@end
@interface PubgLoad()
@end

@implementation PubgLoad
static PubgLoad *extraInfo;
static BOOL MenDeal;

+ (void)load
{
dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

extraInfo =  [PubgLoad new];
[extraInfo Turnonverification];
});
}

    //开启验证 API
    - (void)Turnonverification {
    //为了完整的流程走完,可以打开一次这个方法编译,来模拟没有安装过描述文件
    //[KeyChainOperrationTool clearIMEI];
    NSMutableDictionary *paramsovm = [NSMutableDictionary dictionary];
    paramsovm[@"api"] = @"BSphpSeSsL.in";//BSphpSeSsL.in
    paramsovm[@"date"] = [self getSystemDate];
    paramsovm[@"md5"] = @"";
    paramsovm[@"mutualkey"] = BSPHP_MUTUALKEY;
    __weak typeof(self) weakself = self;
    [NetTool Post_AppendURL:BSPHP_HOST parameters:paramsovm success:^(id responseObject) {
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
    if (!dict) {
    exit(0);
    }
    if (dict) {
    weakself.baseDict = dict;
    [weakself Getversion];
    }
    } failure:^(NSError *error) {
    exit(0);
    }];
    }

    - (void )Getversion {// 获取版本号 API
    NSMutableDictionary *paramsovm = [NSMutableDictionary dictionary];
    NSString *appsafecode = [self getSystemDate];
    paramsovm[@"api"] = @"v.in";//api=v.in
    paramsovm[@"BSphpSeSsL"] = self.baseDict[@"response"][@"data"];
    paramsovm[@"date"] = [self getSystemDate];
    paramsovm[@"md5"] = @"";
    paramsovm[@"mutualkey"] = BSPHP_MUTUALKEY;
    paramsovm[@"currentVersion"] = BSPHP_VERSION;
    paramsovm[@"appsafecode"] = appsafecode;
    [NetTool Post_AppendURL:BSPHP_HOST parameters:paramsovm success:^(id responseObject) {
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
    if (dict) {
    if(![dict[@"response"][@"appsafecode"] isEqualToString:appsafecode]){
    exit(0);
    }
    if([dict[@"response"][@"data"]integerValue] > [PubgLoad currentVersion]){
    UIAlertController *alertController=[UIAlertController alertControllerWithTitle:@"警告" message:@"当前版本已停用,请下载最新版本" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action_jiaqun=[UIAlertAction actionWithTitle:@"点击加入NPC官方Q群" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
    NSString *urlStr = [NSString stringWithFormat:@"mqqapi://card/show_pslcard?src_type=internal&version=1&uin=%@&key=%@&card_type=group&source=external&jump_from=webapi", @"940526118",@"f00c025538a6e30bb133e12660110d9ce96bd1400ca6b07105409a07e258d9a7"];[[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlStr]];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    exit(0);
    });
    }];
    UIAlertAction *action_xiazai=[UIAlertAction actionWithTitle:@"点击下载NPC最新版本" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
    NSString *urlStr = [NSString stringWithFormat: @"https://ios02.top/NPCGF"];[[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlStr]];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    exit(0);
    });
    }];
    [alertController addAction:action_jiaqun];
    [alertController addAction:action_xiazai];
    
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertController animated:YES completion:nil];
    }else {
    NSDate *currentDate = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    NSString *date = [dateFormatter stringFromDate:currentDate];
    NSString *saveDate = [[NSUserDefaults standardUserDefaults]valueForKey:@"outDate"];
    if (saveDate && [saveDate compare:date] == NSOrderedDescending) {
    
    //NSLog(@"卡密有效期内");
    [self  yanzhengOldCode  ];
    return;
    }
    
    //NSLog(@"卡密无效期外");
    [self  startInputAlert];
    }
    }
    } failure:^(NSError *error) {
    exit(0);
    }];
    
    }
    //对比后台版本号
    + (NSInteger)currentVersion {
    return 1;//当前版本号
    }

    - (void)announcement{//  加载公告 API
    NSMutableDictionary *paramsovm = [NSMutableDictionary dictionary];
    paramsovm[@"api"] = @"gg.in";//gg.in
    paramsovm[@"BSphpSeSsL"] = self.baseDict[@"response"][@"data"];
    paramsovm[@"date"] = [self getSystemDate];
    paramsovm[@"md5"] = @"";
    paramsovm[@"mutualkey"] = BSPHP_MUTUALKEY;
    [NetTool Post_AppendURL:BSPHP_HOST parameters:paramsovm success:^(id responseObject) {
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
    if (dict) {
    NSString    *NOTICE= dict[@"response"][@"data"];
    if (NOTICE && NOTICE.length) {
    UIAlertController *alertController=[UIAlertController alertControllerWithTitle:@"最新公告" message:NOTICE preferredStyle:UIAlertControllerStyleAlert];

    UIAlertAction *action=[UIAlertAction actionWithTitle:@"已读" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    }];
    
    [alertController addAction:action];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertController animated:YES completion:nil];
    }
    } else {
    }
    } failure:^(NSError *error) {
    exit(0);
    }];
    
    }
    - (void)startInputAlert
    {
    
    UIAlertController *alertController=[UIAlertController alertControllerWithTitle:@"NPC" message:@"请用正常时间登录,授权成功后改时间!" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {textField.placeholder = @"请在60秒内输入授权码!";
    }];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(60 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{exit(0);});
    UIAlertAction *action=[UIAlertAction actionWithTitle:@"点击授权" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    NSString *password = [alertController.textFields firstObject].text;
    [self Verifyrequest:password];
    }];
    
    UIAlertAction *action_buy=[UIAlertAction actionWithTitle:@"购买平台" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    NSString *urlStr = [NSString stringWithFormat:@"https://dwz.cn/SM6DWtyp"];[[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlStr]];
    }];
    
    UIAlertAction *action_cancel=[UIAlertAction actionWithTitle:@"本机UID" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = [self getIDFA];
    MBProgressHUD *progress = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
    progress.mode = MBProgressHUDModeText;
    progress.label.text = @" UID复制成功,请发送管理员 ";
    [self performSelector:@selector(removehProgress) withObject:nil afterDelay:2.];
        
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    [self  startInputAlert];
    });
    }];
    
    [alertController addAction:action];
    [alertController addAction:action_cancel];
    [alertController addAction:action_buy];
    self.alertController = alertController;
    
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertController animated:YES completion:nil];
    }

    // 验证使用 API
    - (void)Verifyrequest:(NSString *)text {
    if (text.length > 0) {
    NSMutableDictionary *paramsovm = [NSMutableDictionary dictionary];
    NSString *appsafecode = [self getSystemDate];
    paramsovm[@"api"] = @"login.ic";//login.ic
    paramsovm[@"BSphpSeSsL"] = self.baseDict[@"response"][@"data"];
    paramsovm[@"date"] = [self getSystemDate];
    paramsovm[@"md5"] = @"";
    paramsovm[@"mutualkey"] = BSPHP_MUTUALKEY;
    paramsovm[@"icid"] = text;
    paramsovm[@"icpwd"] = @"";
    paramsovm[@"key"] = [self getIDFA];
    paramsovm[@"maxoror"] = [self getIDFA];
    paramsovm[@"appsafecode"] = appsafecode;
    [NetTool Post_AppendURL:BSPHP_HOST parameters:paramsovm success:^(id responseObject) {
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
    if (dict) {
    if(![dict[@"response"][@"appsafecode"] isEqualToString:appsafecode]){
    exit(0);
    dict[@"response"][@"data"] = @"-2000";
    exit(0);
    }
    NSString *dataString = dict[@"response"][@"data"];
    NSRange range = [dataString rangeOfString:@"|1081|"];
    if(![dataString containsString:[self getIDFA]]){
    [self.alertController dismissViewControllerAnimated:YES completion:nil];
    MBProgressHUD *progress = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
    progress.mode = MBProgressHUDModeText;
    progress.label.text = @"授权失败,请检查卡号是否填入正确!";
    [self performSelector:@selector(removehProgress) withObject:nil afterDelay:3.];
                    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    [self startInputAlert];
    });
    return ;
    }
    if (range.location != NSNotFound) {
    [self.alertController dismissViewControllerAnimated:YES completion:nil];
                    
    NSRange start = [dataString rangeOfString:@"||"];
    NSRange end = [dataString rangeOfString:@"|||||"];
    NSRange range = NSMakeRange(start.location + start.length, end.location - start.location - start.length);
    NSString *result = [dataString substringWithRange:range];
                    
    [[NSUserDefaults standardUserDefaults]setValue:result forKey:@"outDate"];
    [[NSUserDefaults standardUserDefaults]setValue:text forKey:@"oldCode"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    MBProgressHUD *progress = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
    progress.mode = MBProgressHUDModeText;
    progress.label.text = [NSString stringWithFormat:@"授权验证成功,软件到期时间:%@",result];
    [self performSelector:@selector(removehProgress) withObject:nil afterDelay:3.5];
    [self initTapGes];
    [self tapIconView];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    [self announcement];
    });
    }else{
    MBProgressHUD *progress = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
    progress.mode = MBProgressHUDModeText;
    progress.label.text = dataString;
    [self performSelector:@selector(removehProgress) withObject:nil afterDelay:3.];
                    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    [self startInputAlert];
    });
    }
    }
    } failure:^(NSError *error) {
    exit(0);
    }];
    }else{
    MBProgressHUD *progress = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
    progress.mode = MBProgressHUDModeText;
    progress.label.text = @"当前授权码不可为空!";
    [self performSelector:@selector(removehProgress) withObject:nil afterDelay:3.];
        
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    [self startInputAlert];
    });
    }
    }

    //判断是否验证
    - (void)yanzhengOldCode{
    NSString *text  = [[NSUserDefaults standardUserDefaults ]valueForKey:@"oldCode"];
    if (text && text.length > 0) {
    NSMutableDictionary *paramsovm = [NSMutableDictionary dictionary];
    NSString *appsafecode = [self getSystemDate];
    paramsovm[@"api"] = @"login.ic";//login.ic
    paramsovm[@"BSphpSeSsL"] = self.baseDict[@"response"][@"data"];
    paramsovm[@"date"] = [self getSystemDate];
    paramsovm[@"md5"] = @"";
    paramsovm[@"mutualkey"] = BSPHP_MUTUALKEY;
    paramsovm[@"icid"] = text;
    paramsovm[@"icpwd"] = @"";
    paramsovm[@"key"] = [self getIDFA];
    paramsovm[@"maxoror"] = [self getIDFA];
    paramsovm[@"appsafecode"] = appsafecode;
    [NetTool Post_AppendURL:BSPHP_HOST parameters:paramsovm success:^(id responseObject) {
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
    if (dict) {
    if(![dict[@"response"][@"appsafecode"] isEqualToString:appsafecode]){
    exit(0);
    dict[@"response"][@"data"] = @"-2000";
    exit(0);
    }
    NSString *dataString = dict[@"response"][@"data"];
    NSRange range = [dataString rangeOfString:@"|1081|"];
    if(![dataString containsString:[self getIDFA]]){
    [self.alertController dismissViewControllerAnimated:YES completion:nil];
    [self startInputAlert];
    return ;
    }
    if (range.location != NSNotFound) {
    [self.alertController dismissViewControllerAnimated:YES completion:nil];
    NSRange start = [dataString rangeOfString:@"||"];
    NSRange end = [dataString rangeOfString:@"|||||"];
    NSRange range = NSMakeRange(start.location + start.length, end.location - start.location - start.length);
    NSString *result = [dataString substringWithRange:range];
    [[NSUserDefaults standardUserDefaults]setValue:result forKey:@"outDate"];
    [[NSUserDefaults standardUserDefaults]setValue:text forKey:@"oldCode"];
    [[NSUserDefaults standardUserDefaults] synchronize];
                    
    MBProgressHUD *progress = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
    progress.mode = MBProgressHUDModeText;
    progress.label.text = [NSString stringWithFormat:@"软件有效期至:%@",result];
    [self performSelector:@selector(removehProgress) withObject:nil afterDelay:3.5];
    [self initTapGes];
    [self tapIconView];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    [self announcement];
    });
    }else{
    [self startInputAlert];
    }
    }
    } failure:^(NSError *error) {
    exit(0);
    }];
    }else{
    [self startInputAlert];
    }

    }
    - (void)removehProgress
    {

    [MBProgressHUD hideHUDForView:[UIApplication sharedApplication].keyWindow animated:YES];
    }

    - (NSString *)getSystemDate{
    NSDate *currentDate = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY/MM/dd#HH:mm:ss"];
    return [dateFormatter stringFromDate:currentDate];
    }

    -(NSString *)getIDFA{
    NSString * IDFA = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
    return IDFA;
    }
    - (void)initTapGes
    {
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    tap.numberOfTapsRequired = 3;//点击次数
    tap.numberOfTouchesRequired = 3;//手指数
    [[JHPP currentViewController].view addGestureRecognizer:tap];
    [tap addTarget:self action:@selector(tapIconView)];

    }
    - (void)tapIconView
    {

    JHDragView *view = [[UIApplication sharedApplication].keyWindow viewWithTag:100];
    if (!view)
    {
    view = [[JHDragView alloc] init];
    view.tag = 100;
    [[JHPP currentViewController].view addSubview:view];
        
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onConsoleButtonTapped:)];
    tap.numberOfTapsRequired = 1;
    [view addGestureRecognizer:tap];
    
    }
    if (!MenDeal)
    {

    view.hidden = NO;

    } else {
       
    view.hidden = YES;
    }
    
    MenDeal = !MenDeal;
    }
    - (void)onConsoleButtonTapped:(id)sender
    {

    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
    [alert addTimerToButtonIndex:0 reverse:YES];

    #pragma mark 主菜单页面
    [alert addButton:@"点击注入防封" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float search = 67109633;
    engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
    vector<void*>results = engine.getAllResults();
    float modify = 67109634;
    for(int i = 0; i < results.size(); i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);
    }
    });
    }];

    [alert addButton:@"开启常用功能" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)),
    dispatch_get_main_queue(), ^{
    [self cygn];
    });
    }];

    [alert addButton:@"开启变态功能" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)),
    dispatch_get_main_queue(), ^{
    [self btgn];
    });
    }];

    [alert addButton:@"开启飞天功能" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)),
    dispatch_get_main_queue(), ^{
    [self ftgn];
    });
    }];

    [alert addButton:@"开启枪械功能" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)),
    dispatch_get_main_queue(), ^{
    [self zdgn];
    });
    }];

    [alert addButton:@"开启测试功能" actionBlock:^{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)),
    dispatch_get_main_queue(), ^{
    [self csgn];
    });
    }];

    [alert showSuccess:@"NPC-文明重启" subTitle:@"欢迎使用NPC第三方辅助\n合理规划游戏时间\n抵制不良游戏习惯" closeButtonTitle:@"关闭菜单" duration:0];

    }
    - (void)ftgn
    {

    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"飞天300米-开" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 10;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 300;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"飞天300米-关" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 300;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 10;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];

    }
    - (void)txzq
    {

    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"直立天线" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x250000000};
    float search = -0.9855342507362366;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 1e+08;
    for(int i = 0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"视觉天线" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x250000000};
    float search = 0.16947640479;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 1e+08;
    for(int i = 0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"返回上页" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    [self cygn];
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];

    }
    - (void)stfw
    {
        
    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"身体0.3" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float search = 0.16;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0.3;
    for(int i = 0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"身体0.6" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float search = 0.16;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0.6;
    for(int i = 0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"身体1.0" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float search = 0.16;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 1;
    for(int i = 0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"身体1.5" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float search = 0.16;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 1.5;
    for(int i = 0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"身体2.0" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float search = 0.16;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 2.0;
    for(int i = 0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"返回上页" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    [self fwzq];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];

    }
    - (void)tbfw
    {

    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"头部0.3" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float search = 0.11;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0.3;
    for(int i = 0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"头部0.6" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float search = 0.11;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0.6;
    for(int i = 0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"头部1.0" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
        float search = 0.11;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
        float modify = 1.0;
    for(int i = 0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"头部1.5" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
        float search = 0.11;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
        float modify = 1.5;
    for(int i = 0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"头部2.0" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float search = 0.11;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
        float modify = 1.8;
    for(int i = 0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"返回上页" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    [self fwzq];
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];

    }
    - (void)cygn
    {

    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"天线专区" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    [self txzq];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"范围专区" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    [self fwzq];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"机瞄十倍" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 48;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 1.401298e-45;
    engine.JRNearBySearch(0x50,&Nearsearch,JR_Search_Type_Float);
    float search1 = 48;
    engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 10;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"昼夜交替" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search1 = 0.0066999997943639755;
    engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
    float search2 = 9.219422856485836E-41;
    engine.JRNearBySearch(0x100, &search2, JR_Search_Type_Float);
    float search3 = 9.219422856485836E-41;
    engine.JRScanMemory(range, &search3, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = -999;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"人物半遁" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    dispatch_queue_t queue = dispatch_queue_create("net.bujige.testQueue", DISPATCH_QUEUE_SERIAL);dispatch_async(queue, ^{
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x350000000};
    float search = 1.0400390625;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    self.dundi3 = results;
    float modify = 1.98;
    for(int i =0;i<results.size();i++){
    if (i == results.size() - 1) {
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }
    });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    if(self.dundi3.size() > 0) {
    [NSTimer scheduledTimerWithTimeInterval:0.1 repeats:YES block:^(NSTimer * _Nonnull timer) {
    dispatch_queue_t queue = dispatch_queue_create("net.bddujige.testQueue", DISPATCH_QUEUE_SERIAL);
    dispatch_async(queue, ^{
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    float modify = 1.98;
    for(int i =0;i<self.dundi3.size();i++){
    if (i == self.dundi3.size() - 1) {
    engine.JRWriteMemory((unsigned long long)(self.dundi3[i]),&modify,JR_Search_Type_Float);
    }
    }
    });
    }];
    }
    });
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"备用半遁" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    dispatch_queue_t queue = dispatch_queue_create("net.bujige.testQueue", DISPATCH_QUEUE_SERIAL);dispatch_async(queue, ^{
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x350000000};
    uint32_t search = 1065689088;
    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
    vector<void*>results = engine.getAllResults();
    uint32_t modify = 1073722337;
    for(int i =0;i<results.size();i++){
    if (i == results.size() - 1) {
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_UInt);
    }
    }
    });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    if(self.dundi3.size() > 0) {
        [NSTimer scheduledTimerWithTimeInterval:0.1 repeats:YES block:^(NSTimer * _Nonnull timer) {
    dispatch_queue_t queue = dispatch_queue_create("net.bddujige.testQueue", DISPATCH_QUEUE_SERIAL);
    dispatch_async(queue, ^{
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    uint32_t modify = 1073722337;
    for(int i =0;i<self.dundi3.size();i++){
    if (i == self.dundi3.size() - 1) {
    engine.JRWriteMemory((unsigned long long)(self.dundi3[i]),&modify,JR_Search_Type_Float);
    }
    }
    });
    }];
    }
    });
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"人物离线(男)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x250000000};
    float search = 6.375604601571521E-24;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 1.3370429788205679E23;
    engine.JRNearBySearch(0x20,&Nearsearch,JR_Search_Type_Float);
    float Nearsearch2 = 0;
    engine.JRNearBySearch(0x20,&Nearsearch2,JR_Search_Type_Float);
    float search2 = 1.3370429788205679E23;
    engine.JRScanMemory(range, &search2, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 2.79703205e-33;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"人物离线(女)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x250000000};
    float search = 2.3057977e-38;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 2.79703205e-33;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];

    }
    - (void)fwzq
    {
            
    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"头部范围" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    [self tbfw];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"身体范围" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    [self stfw];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"返回上页" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    [self cygn];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];

    }
    - (void)btgn
    {

    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"第一人称" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x000000000,0x300000000};
    float search = 1.7;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = -1;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"第三人称" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float search = 1.7;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 3;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"水下行走" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 0.00999999978;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float search1 = 10000;
    engine.JRNearBySearch(0x100, &search1, JR_Search_Type_Float);
    float search2 = 10000;
    engine.JRScanMemory(range, &search2, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"浮空建造" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x250000000};
    uint64_t search = 1180667905;
    engine.JRScanMemory(range, &search, JR_Search_Type_SLong);
    uint64_t Nearsearch = 16843008;
    engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_SLong);
    uint64_t search1 = 16843008;
    engine.JRScanMemory(range, &search1, JR_Search_Type_SLong);
    uint64_t search2 = 9772562;
    engine.JRScanMemory(range, &search2, JR_Search_Type_SLong);
    vector<void*>results = engine.getAllResults();
    uint64_t modify = 9772562;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    });
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"浮空地基" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x250000000};
    uint64_t search = 1125899906842625;
    engine.JRScanMemory(range, &search, JR_Search_Type_SLong);
    uint64_t Nearsearch = 4503600701112320;
    engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_SLong);
    uint64_t search1 = 1125899906842625;
    engine.JRScanMemory(range, &search1, JR_Search_Type_SLong);
    vector<void*>results = engine.getAllResults();
    uint64_t modify = 206403243343873;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SLong);
    }
    });
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"强制建造" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x250000000};
    float search = 54.394535064697266;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    });
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"卡地基领-开" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 1.5;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
        float modify = -1.5;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];
            
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"卡地基领-关" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = -1.5;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = -1.5;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"打开下页" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    [self xyy1];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];

    }
    - (void)zdgn
    {

    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];
    //三级菜单
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"无后聚点" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    [self whjd];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"瞬击专区" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    [self sjzq];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"秒换专区" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    [self mhzq];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"瞬爆专区" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    [self sbzq];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];

    }
    - (void)whjd
    {
        
    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"无后专区" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    [self whzq];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"聚点专区" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    [self jdzq];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"返回上页" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    [self zdgn];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];

    }
    - (void)sjzq
    {

    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"SMG瞬击" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 300;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 1;
    engine.JRNearBySearch(0x50,&Nearsearch,JR_Search_Type_Float);
    float Nearsearch1 = 0;
    engine.JRNearBySearch(0x50,&Nearsearch1,JR_Search_Type_Float);
    float search1 = 300;
    engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 9999;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"QBZ瞬击" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 790;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 1;
    engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
    float search1 = 790;
    engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 9999;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"FMS瞬击" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 360;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 1;
    engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
    float search1 = 360;
    engine.JRNearBySearch(0x10,&search1,JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 9999;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"UZI瞬击" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 320;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 1;
    engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
    float Nearsearch1 = 0;
    engine.JRNearBySearch(0x10,&Nearsearch1,JR_Search_Type_Float);
    float search1 = 320;
    engine.JRNearBySearch(0x10,&search1,JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    for(int i =0;i<results.size();i++){
    float modify = 9999;
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"M4A1瞬击" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 830;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 1;
    engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
    float search1 = 830;
    engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 9999;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"AK47瞬击" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 12;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 6;
    engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
    float Nearsearch1 = 4;
    engine.JRNearBySearch(0x10,&Nearsearch1,JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 9999;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"返回上页" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    [self zdgn];
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];

    }
    - (void)mhzq
    {

    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"SMG秒换(手动)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 2;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0.01;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"SMG秒换(自动)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 2.66666674614;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0.01;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"UZI秒换(手动)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 2.83333349228;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0.01;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"FMZ秒换(手动)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 2.76666688919;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0.01;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"QBZ秒换(手动)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 2.03333353996;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0.01;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"QBZ秒换(自动)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 2.90000009537;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0.01;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"M4/AK秒换(手动)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 2.16666674614;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0.01;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"M4/AK秒换(自动)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 2.66666674614;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0.01;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"返回上页" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    [self zdgn];
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];

    }
    - (void)sbzq
    {

    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"RPG瞬爆" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 3;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 35;
    engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
    float Nearsearch1 = 20;
    engine.JRNearBySearch(0x100,&Nearsearch1,JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    float Nearsearch2 = 40;
    engine.JRNearBySearch(0x100,&Nearsearch2,JR_Search_Type_Float);
    float search1 = 40;
    engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
    vector<void*>results1 = engine.getAllResults();
    float modify1 = 99999;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results1[i]),&modify1,JR_Search_Type_Float);
    }
    }]];
            
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"榴弹瞬爆" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    uint64_t search = 4728779609789274522;
    engine.JRScanMemory(range, &search, JR_Search_Type_SLong);
    vector<void*>results = engine.getAllResults();
    uint64_t modify = 1050253722;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SLong);
    }
    float Nearsearch2 = 25;
    engine.JRNearBySearch(0x100,&Nearsearch2,JR_Search_Type_Float);
    float search2 = 25;
    engine.JRScanMemory(range, &search2, JR_Search_Type_Float);
    vector<void*>results1 = engine.getAllResults();
    float modify1 = 99999;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results1[i]),&modify1,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"RPG速换" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 2.10000014305;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 1.0;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"RPG趴下速换" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 2.76666688919;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 1.55;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"返回上页" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    [self zdgn];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];

    }
    - (void)whzq
    {

    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"AK无后" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search1 = 14;
    engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
    float search2 = 4;
    engine.JRNearBySearch(0x100, &search2, JR_Search_Type_Float);
    float search3 = 4;
    engine.JRNearBySearch(0x100, &search3, JR_Search_Type_Float);
    float search4 = 4;
    engine.JRScanMemory(range, &search4, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"QBZ无后" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search1 = 12;
    engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
    float search2 = 4;
    engine.JRNearBySearch(0x100, &search2, JR_Search_Type_Float);
    float search3 = 4;
    engine.JRNearBySearch(0x100, &search3, JR_Search_Type_Float);
    float search4 = 4;
    engine.JRScanMemory(range, &search4, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"M4无后" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search1 = 12;
    engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
    float search2 = 4;
    engine.JRNearBySearch(0x100, &search2, JR_Search_Type_Float);
    float search3 = 4;
    engine.JRNearBySearch(0x100, &search3, JR_Search_Type_Float);
    float search4 = 4;
    engine.JRScanMemory(range, &search4, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"UZI无后" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search1 = 16;
    engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
    float search2 = 4;
    engine.JRNearBySearch(0x100, &search2, JR_Search_Type_Float);
    float search3 = 4;
    engine.JRNearBySearch(0x100, &search3, JR_Search_Type_Float);
    float search4 = 4;
    engine.JRScanMemory(range, &search4, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"SMG无后" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action){
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search1 = 15;
    engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
    float search2 = 4;
    engine.JRNearBySearch(0x100, &search2, JR_Search_Type_Float);
    float search3 = 4;
    engine.JRNearBySearch(0x100, &search3, JR_Search_Type_Float);
    float search4 = 4;
    engine.JRScanMemory(range, &search4, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"返回上页" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    [self whjd];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];

    }
    - (void)jdzq
    {

    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"SMG/FMS聚点" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x290000000};
    float search = 3;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 2.5;
    engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"QBZ/M4聚点" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x290000000};
    float search = 6;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 3.5;
    engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"AK47聚点" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search1 = 14;
    engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
    float search2 = 6;
    engine.JRNearBySearch(0x100, &search2, JR_Search_Type_Float);
    float search3 = 6;
    engine.JRNearBySearch(0x100, &search3, JR_Search_Type_Float);
    float search4 = 6;
    engine.JRScanMemory(range, &search4, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"UZI聚点" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 16;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 2;
    engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
    float Nearsearch1 = 3;
    engine.JRNearBySearch(0x10,&Nearsearch1,JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"返回上页" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    [self whjd];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];

    }
    - (void)xyy1
    {

    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"上帝视角-开" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 1.5;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 30;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"上帝视角-关" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 30;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 1.5;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"灵魂穿墙(用完大退关闭)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    dispatch_queue_t queue1 = dispatch_queue_create("net.bujige.testQueue", DISPATCH_QUEUE_SERIAL);dispatch_async(queue1, ^{
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 1.0e32;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 0.005;
    engine.JRNearBySearch(0x10,&Nearsearch,JR_Search_Type_Float);
    float search1 = 1.0e32;
    engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 8.8888;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    dispatch_queue_t queue = dispatch_queue_create("net.bujige.testQueue", DISPATCH_QUEUE_SERIAL);dispatch_async(queue, ^{
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    uint32_t search = 8391610;
    engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
    vector<void*>results = engine.getAllResults();
    uint32_t modify = 0;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_UInt);
    }
    });
    });
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"全图子弹-开" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float search = 1.401298464324817E-41;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 1.401298464324817E-43;
    engine.JRNearBySearch(0x20,&Nearsearch,JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"全图子弹-关(大退)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float search = 1.401298464324817E-41;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 1.401298464324817E-43;
    engine.JRNearBySearch(0x20,&Nearsearch,JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 7.006492321624085E-42;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"返回上页" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    [self btgn];
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];

    }
    - (void)csgn
    {

    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"零度" message:@""
    preferredStyle:UIAlertControllerStyleAlert];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"趴下遁地" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float search = 0.4331;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 2;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    //[alertCtrl addAction:[UIAlertAction actionWithTitle:@"站立遁地" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    //JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    //AddrRange range = (AddrRange){0x100000000,0x160000000};
    //float search = 1.03999996185;
    //engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    //vector<void*>results = engine.getAllResults();
    //float modify = 8;
    //for(int i =0;i<results.size();i++){
    //engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    //}
    //}]];

    //[alertCtrl addAction:[UIAlertAction actionWithTitle:@"一键高跳" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    //JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    //AddrRange range = (AddrRange){0x100000000,0x160000000};
    //float search = 1.03999996185;
    //engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    //vector<void*>results = engine.getAllResults();
    //float modify = -300;
    //for(int i =0;i<results.size();i++){
    //engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    //}
    //}]];
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"物资传送1(测试)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float search = 14308;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    float Nearsearch = 4.2039e-45;
    engine.JRNearBySearch(0x100,&Nearsearch,JR_Search_Type_Float);
    float Nearsearch1 = 1.4013e-45;
    engine.JRNearBySearch(0x100,&Nearsearch1,JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 1.4013e-45;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"物资传送2(测试)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float search = 1113166849;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 1;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"陷入遁地-开" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x160000000};
    float search = -1.0e32;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0.1179953374;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"陷入遁地-关" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x160000000};
    float search = 0.1179953374;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = -1.0e32;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"全图定怪(测试)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x300000000};
    float  search1 = 18;
    engine.JRScanMemory(range, &search1, JR_Search_Type_Float);
    float search2 = 272;
    engine.JRNearBySearch(0x50,&search2,JR_Search_Type_Float);
    float search3 = 0.1;
    engine.JRScanMemory(range, &search3, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float  modify = 999;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];

    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"实体货轮(失效)" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
    AddrRange range = (AddrRange){0x100000000,0x200000000};
    float search = 10000;
    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
    vector<void*>results = engine.getAllResults();
    float modify = 0.9981;
    for(int i =0;i<results.size();i++){
    engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
    }
    }]];
        
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"关闭菜单" style:UIAlertActionStyleDefault handler:nil]];
    [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];
    }

    #pragma mark// 提示条
    - (void)showMessage:(NSString *)message duration:(NSTimeInterval)time
    {
    CGSize screenSize = [[UIScreen mainScreen] bounds].size;

    UIWindow * window = [UIApplication sharedApplication].keyWindow;
    UIView *showview =  [[UIView alloc]init];
    showview.backgroundColor = [UIColor whiteColor];
    showview.frame = CGRectMake(1, 1, 1, 1);
    showview.alpha = 1.0f;
    showview.layer.cornerRadius = 5.0f;
    showview.layer.masksToBounds = YES;
    [window addSubview:showview];

    UILabel *label = [[UILabel alloc]init];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;

    NSDictionary *attributes = @{NSFontAttributeName:[UIFont systemFontOfSize:15.f],
    NSParagraphStyleAttributeName:paragraphStyle.copy};

    CGSize labelSize = [message boundingRectWithSize:CGSizeMake(207, 999)
    options:NSStringDrawingUsesLineFragmentOrigin
    attributes:attributes context:nil].size;

    label.frame = CGRectMake(10, 5, labelSize.width +20, labelSize.height);
    label.text = message;
    label.textColor = [UIColor blackColor];
    //label.textAlignment = 1;
    label.backgroundColor = [UIColor whiteColor];
    label.font = [UIFont boldSystemFontOfSize:15];
    [showview addSubview:label];

    showview.frame = CGRectMake((screenSize.width - labelSize.width - 20)/2,
    screenSize.height - 300,
    labelSize.width+40,
    labelSize.height+10);
    [UIView animateWithDuration:time animations:^{
    showview.alpha = 0;
    } completion:^(BOOL finished) {
    [showview removeFromSuperview];
    }];
    }

    @end
