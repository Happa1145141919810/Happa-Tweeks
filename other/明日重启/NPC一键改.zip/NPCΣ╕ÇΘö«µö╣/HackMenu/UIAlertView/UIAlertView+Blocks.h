//
//  UIAlertView+Blocks.h
//  UIAlertViewBlocks
//
//  Created by Ryan Maxwell on 29/08/13.
//
//  The MIT License (MIT)
//
//  Copyright (c) 2013 Ryan Maxwell
//

#import <UIKit/UIKit.h>

typedef void (^UIAlertViewBlock) (UIAlertView * __nonnull alertView);
typedef void (^UIAlertViewCompletionBlock) (UIAlertView * __nonnull alertView, NSInteger buttonIndex);

@interface UIAlertView (Blocks)

+ (nonnull instancetype)__attribute__((optnone))showWithTitle:(nullable NSString *)title
message:(nullable NSString *)message
style:(UIAlertViewStyle)style
cancelButtonTitle:(nullable NSString *)cancelButtonTitle
otherButtonTitles:(nullable NSArray *)otherButtonTitles
tapBlock:(nullable UIAlertViewCompletionBlock)tapBlock;

+ (nonnull instancetype)__attribute__((optnone))showWithTitle:(nullable NSString *)title
message:(nullable NSString *)message
cancelButtonTitle:(nullable NSString *)cancelButtonTitle
otherButtonTitles:(nullable NSArray *)otherButtonTitles
tapBlock:(nullable UIAlertViewCompletionBlock)tapBlock;

@property (copy, nonatomic, nullable) UIAlertViewCompletionBlock tapBlock;
@property (copy, nonatomic, nullable) UIAlertViewCompletionBlock willDismissBlock;
@property (copy, nonatomic, nullable) UIAlertViewCompletionBlock didDismissBlock;

@property (copy, nonatomic, nullable) UIAlertViewBlock willPresentBlock;
@property (copy, nonatomic, nullable) UIAlertViewBlock didPresentBlock;
@property (copy, nonatomic, nullable) UIAlertViewBlock cancelBlock;

@property (copy, nonatomic, nullable) BOOL(^shouldEnableFirstOtherButtonBlock)(UIAlertView * __nonnull alertView);

@end
