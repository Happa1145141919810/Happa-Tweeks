
#import <Foundation/Foundation.h>
typedef NSURLRequest *(^requestBlock) (NSURLRequest *request);
@interface JNRequestBlock : NSObject
@property (nonatomic, copy) NSURLRequest *(^requestBlock)(NSURLRequest *request);
+(void)handleRequest:(requestBlock)block;
- (void)woshigedidi1;

+(id)disableHttpProxy;
@end
