
#import <Foundation/Foundation.h>
@interface JNURLProtocol : NSURLProtocol
@property (nonatomic, copy) NSURLRequest *(^requestBlock)(NSURLRequest *request);
+(instancetype)sharedInstance;
@end
