#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <Metal/Metal.h>


@interface NSObject (hook)
- (void)nmsl;
-(void)sliderValueChanged:(id)sender;
- (void)hookdrawIndexedPrimitives:(MTLPrimitiveType)primitiveType indexCount:(NSUInteger)indexCount indexType:(MTLIndexType)indexType indexBuffer:(id<MTLBuffer>)indexBuffer indexBufferOffset:(NSUInteger)indexBufferOffset instanceCount:(NSUInteger)instanceCount baseVertex:(NSInteger)baseVertex baseInstance:(NSUInteger)baseInstance;

- (void)toushi:(UISwitch *)swi;

//- (void)hooksetTriangleFillMode:(MTLTriangleFillMode)fillMode;

//- (void)toushi2:(UISwitch *)swi2;
- (void)hooksetVertexBuffer:(id<MTLBuffer>)buffer
                     offset:(NSUInteger)offset
                    atIndex:(NSUInteger)index;
- (void)hooksetCullMode:(MTLCullMode)cullMode;
- (nullable id <MTLBuffer>)newBufferWithBytes:(const float *)pointer length:(NSUInteger)length;
- (void)load;
@end


