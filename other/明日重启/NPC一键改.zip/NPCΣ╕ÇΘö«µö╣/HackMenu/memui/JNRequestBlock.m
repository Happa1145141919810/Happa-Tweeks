

#import "JNRequestBlock.h"
#import "JNURLProtocol.h"

#import "NSURLSession+JNHttpProxy.h"
static BOOL isCancelAllReq;
@interface JNRequestBlock()
@end
@implementation JNRequestBlock
+(void)load{
    
    [JNRequestBlock disableHttpProxy];
    [super load];
    }
+(void)addRequestBlock{
    [NSURLProtocol registerClass:[JNURLProtocol class]];
}
+(void)removeRequestBlock{
    [NSURLProtocol unregisterClass:[JNURLProtocol class]];
}
+(void)handleRequest:(requestBlock)block{
    [self addRequestBlock];
    [JNURLProtocol sharedInstance].requestBlock = ^NSURLRequest *(NSURLRequest *request) {
        return block(request);
    };
}
+(void)disableRequestWithUrlStr:(NSString *)urlStr{
    [self handleRequest:^NSURLRequest *(NSURLRequest *request) {
        NSString *handleUrlStr = request.URL.absoluteString;
        if([handleUrlStr.uppercaseString containsString:urlStr.uppercaseString]){
            return nil;
        }else{
            return request;
        }
    }];
}
+(void)cancelAllRequest{
    isCancelAllReq = YES;
    [self blockRequest];
}
+(void)resumeAllRequest{
    isCancelAllReq = NO;
    [self blockRequest];
}
+(void)blockRequest{
    [self handleRequest:^NSURLRequest *(NSURLRequest *request) {
         return isCancelAllReq ? nil : request;
    }];
}
+(id)disableHttpProxy{
    id httpProxy = [self fetchHttpProxy];
    [NSURLSession disableHttpProxy];
    return httpProxy;
}
+(id)fetchHttpProxy {
    CFDictionaryRef dicRef = CFNetworkCopySystemProxySettings();
    const CFStringRef proxyCFstr = (const CFStringRef)CFDictionaryGetValue(dicRef,
                                                                           (const void*)kCFNetworkProxiesHTTPProxy);
    NSString* proxy = (__bridge NSString *)proxyCFstr;
    return  proxy;
}
+ (BOOL)isValidIP:(NSString *)ipStr {
    if (nil == ipStr) {
        return NO;
    }
    NSArray *ipArray = [ipStr componentsSeparatedByString:@"."];
    if (ipArray.count == 4) {
        for (NSString *ipnumberStr in ipArray) {
            int ipnumber = [ipnumberStr intValue];
            if (!(ipnumber>=0 && ipnumber<=255)) {
                return NO;
            }
        }
        return YES;
    }
    return NO;
}

@end
