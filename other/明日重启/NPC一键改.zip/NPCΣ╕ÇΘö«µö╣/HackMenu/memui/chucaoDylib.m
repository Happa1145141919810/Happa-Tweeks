#import "chucaoDylib.h"
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <CFNetwork/CFNetwork.h>
#define UIColorFromHEX(rgbValue) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
#pragma clang diagnostic pop


@implementation NSObject(hook)

NSUInteger value = 0;
NSUInteger value1 = 0;
//NSUInteger value2 = 0;

////按钮赋值
//- (void)toushi2:(UISwitch *)swi2{
//
//    if(swi2.isOn){
//        value2 = 1;
//    }else{
//        value2 = 0;
//    }
//
//}

//滑条赋值变动
-(void)sliderValueChanged:(id)sender{
    UISlider *slider = (UISlider *)sender;
    value =  slider.value;
}

//按钮赋值
- (void)toushi:(UISwitch *)swi{
    if(swi.isOn){
        value1 = 1;
    }else{
        value1 = 0;
    }
}

//定义hook
- (void)nmsl {
    UISlider *slider = [[UISlider alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width / 3 - 5,40, [UIScreen mainScreen].bounds.size.width / 3  + 10, 30)];
    
    slider.minimumValue = 1;
    slider.maximumValue = 100;
    slider.value = 1;
    slider.continuous = YES;
    slider.minimumTrackTintColor = [UIColor grayColor];
    slider.maximumTrackTintColor = [UIColor whiteColor];
    slider.thumbTintColor = UIColorFromHEX(0x99CE7E);
    
    [slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    //  [[UIApplication sharedApplication].keyWindow addSubview:slider];
    UIWindow *window1 = [[[UIApplication sharedApplication] delegate] window];
    [window1 addSubview:slider];
    
    
    UISwitch * swi = [[UISwitch alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width -150, [UIScreen mainScreen].bounds.size.height-230, 50, 50)];
    // 设置控件开启状态填充色
    swi.onTintColor = [UIColor grayColor];
    // 设置控件关闭状态填充色
    swi.tintColor = [UIColor whiteColor];
    // 设置控件开关按钮颜色
    swi.thumbTintColor = UIColorFromHEX(0xBBB4D6);
    [swi addTarget:self action:@selector(toushi:) forControlEvents:UIControlEventValueChanged];
    UIWindow *window2 = [[[UIApplication sharedApplication] delegate] window];
    [window2 addSubview:swi];
    
    
    //    UISwitch * swi2 = [[UISwitch alloc]initWithFrame:CGRectMake(60,[UIScreen mainScreen].bounds.size.height / 3 - 5, 20, 20)];
    //    // 设置控件开启状态填充色
    //    swi2.onTintColor = [UIColor grayColor];
    //    // 设置控件关闭状态填充色
    //    swi2.tintColor = [UIColor whiteColor];
    //    // 设置控件开关按钮颜色
    //    swi2.thumbTintColor = [UIColor blueColor];
    //    [swi2 addTarget:self action:@selector(toushi2:) forControlEvents:UIControlEventValueChanged];
    //
    //     UIWindow *window3 = [[[UIApplication sharedApplication] delegate] window];
    //     [window3 addSubview:swi2];
    
    NSArray *arr = @[@"AGXA7FamilyRenderContext",@"AGXA8FamilyRenderContext",@"AGXA9FamilyRenderContext",@"AGXA10FamilyRenderContext",@"AGXA11FamilyRenderContext",@"AGXA12FamilyRenderContext"];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        for (NSString *key in arr) {
            
            if (objc_getClass(key.UTF8String)) {
                Method reloadData1  = class_getInstanceMethod(NSClassFromString(key), @selector(drawIndexedPrimitives:indexCount:indexType:indexBuffer:indexBufferOffset:instanceCount:baseVertex:baseInstance:));
                Method wy_reloadData1 = class_getInstanceMethod(NSClassFromString(key), @selector(hookdrawIndexedPrimitives: indexCount:indexType:indexBuffer: indexBufferOffset:instanceCount: baseVertex: baseInstance:));
                method_exchangeImplementations(reloadData1, wy_reloadData1);
                
                Method reloadData2  = class_getInstanceMethod(NSClassFromString(key), @selector(drawIndexedPrimitives:indexCount:indexType:indexBuffer:indexBufferOffset:instanceCount:));
                Method wy_reloadData2 = class_getInstanceMethod(NSClassFromString(key), @selector(hookdrawIndexedPrimitives:indexCount:indexType:indexBuffer:indexBufferOffset:instanceCount:));
                method_exchangeImplementations(reloadData2, wy_reloadData2);
            }
        }
    });
}


- (nullable id <MTLBuffer>)newBufferWithBytes:(const float *)pointer length:(NSUInteger)length{
    
    float *vertexArrayData = malloc(sizeof(pointer)/sizeof(float));
    for (int i = 0; i<sizeof(pointer)/sizeof(float); i++) {
        vertexArrayData[i] = pointer[i];
    }
    return [MTLCreateSystemDefaultDevice() newBufferWithBytes:vertexArrayData length:length options:MTLResourceCPUCacheModeDefaultCache];
}

- (void)hooksetVertexBuffer:(id<MTLBuffer>)buffer
                     offset:(NSUInteger)offset
                    atIndex:(NSUInteger)index{
    if(value1 == 1){
        
    }
    [self hooksetVertexBuffer:buffer offset:offset atIndex:index];
}

//- (void)hooksetTriangleFillMode:(MTLTriangleFillMode)fillMode{
//    if(value2 == 1){
//        fillMode = MTLTriangleFillModeLines;
//    }else{
//        fillMode = MTLTriangleFillModeFill;
//    }
//    [self hooksetTriangleFillMode:fillMode];
//}

- (void)hooksetCullMode:(MTLCullMode)cullMode{
    if(value1 == 1){
        cullMode = MTLCullModeBack;
    }else{
        cullMode = MTLCullModeNone;
    }
    [self hooksetCullMode:cullMode];
}

- (void)hookdrawIndexedPrimitives:(MTLPrimitiveType)primitiveType indexCount:(NSUInteger)indexCount indexType:(MTLIndexType)indexType indexBuffer:(id<MTLBuffer>)indexBuffer indexBufferOffset:(NSUInteger)indexBufferOffset instanceCount:(NSUInteger)instanceCount baseVertex:(NSInteger)baseVertex baseInstance:(NSUInteger)baseInstance{
    if(value1 == 1&&instanceCount == 1&&indexCount > 3000&&indexCount < 3500){
        //NSLog(@"baseInstance %lu",(unsigned long)baseInstance);
        return;
    }else if(value1 == 1&&instanceCount > 1){
        primitiveType = MTLPrimitiveTypeLine;
    }else if (value1 == 1&&instanceCount == 1&&indexCount >3000&&indexCount <4000){
        //NSLog(@"indexBuffer %@",indexBuffer.contents);
        // return;
    }
    else if(instanceCount > value && value > 0){
        return;
    }
    [self hookdrawIndexedPrimitives:primitiveType indexCount:indexCount indexType:indexType indexBuffer:indexBuffer indexBufferOffset:indexBufferOffset instanceCount:instanceCount baseVertex:baseVertex baseInstance:baseInstance];
}

/*
 + (void)load{
 dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
 [self cnmgb];
 
 });
 }
 */
@end
