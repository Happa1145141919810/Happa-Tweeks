
#import "PubgLoad.h"
#import <UIKit/UIKit.h>
#include <JRMemory/MemScan.h>
#import "JHPP.h"
#import "JHDragView.h"
#import "SCLAlertView.h"
#import "FPSDisplay.h"
#define SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width
@interface FPSDisplay ()
@property (strong, nonatomic) UILabel *displayLabel;
@property (strong, nonatomic) CADisplayLink *link;
@property (assign, nonatomic) NSInteger count;
@property (assign, nonatomic) NSTimeInterval lastTime;
@property (strong, nonatomic) UIFont *font;
@property (strong, nonatomic) UIFont *subFont;
@end
@implementation FPSDisplay
+(void)load
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(20 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    [self shareFPSDisplay];
    });
}
+ (instancetype)shareFPSDisplay {
    static FPSDisplay *shareDisplay;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shareDisplay = [[FPSDisplay alloc] init];
    });
    return shareDisplay;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self initDisplayLabel];
    }
    return self;
}

- (void)initDisplayLabel {
    //CGRect frame = CGRectMake(width/2-100, 0, 260, 15);
        CGRect frame = CGRectMake(SCREEN_WIDTH-300, 0.5, 350, 30);
    self.displayLabel = [[UILabel alloc] initWithFrame: frame];
    self.displayLabel.layer.cornerRadius = 15;
    self.displayLabel.clipsToBounds = YES;
    self.displayLabel.textAlignment = NSTextAlignmentLeft;
    //    self.displayLabel.textAlignment = NSTextAlignmentCenter;
    self.displayLabel.userInteractionEnabled = NO;

    //  self.displayLabel.backgroundColor = [UIColor colorWithWhite:0.000 alpha:0.700];

    _font = [UIFont fontWithName:@"Menlo" size:14];
    if (_font) {
        _subFont = [UIFont fontWithName:@"Menlo" size:4];
    } else {
        _font = [UIFont fontWithName:@"Courier" size:14];
        _subFont = [UIFont fontWithName:@"Courier" size:4];
    }

    [self initCADisplayLink];

    [[UIApplication sharedApplication].keyWindow addSubview:self.displayLabel];
}

- (void)initCADisplayLink {
    self.link = [CADisplayLink displayLinkWithTarget:self selector:@selector(tick:)];
    [self.link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
}

- (void)tick:(CADisplayLink *)link
{
    if(self.lastTime == 0){
        self.lastTime = link.timestamp;
        return;
    }
    self.count += 1;
    NSTimeInterval delta = link.timestamp - _lastTime;
    if(delta >= 1.f){
        self.lastTime = link.timestamp;
        float fps = self.count / delta;
        self.count = 0;
        [self updateDisplayLabelText: fps];
    }
}

- (void)updateDisplayLabelText: (float) fps
{
    NSMutableString *mustr = [[NSMutableString alloc] init];
    [mustr appendFormat:@"%@",self.getSystemDate];
   // self.displayLabel.text = [NSString stringWithFormat:@"%@by刚某侠",mustr];//fps
        self.displayLabel.text = [NSString stringWithFormat:@"%dFPS %@by刚某侠",(int)round(fps),mustr];//fps
    self.displayLabel.textColor = [UIColor colorWithRed: 1.00 green: 0.58 blue: 0.78 alpha: 1.00];;


    self.displayLabel.font = [UIFont systemFontOfSize:11];
}

- (NSString *)getSystemDate
{
    NSDate *currentDate = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //    [dateFormatter setDateFormat:@"HH:mm:ss"];YYYY-MM-DD HH:NN:SS
    [dateFormatter setDateFormat:@" yyyy年MM月dd日HH:mm:ss "];

    return [dateFormatter stringFromDate:currentDate];
}

@end
@interface PubgLoad()
@end

@implementation PubgLoad

static PubgLoad *extraInfo;
static BOOL MenDeal;

+ (void)load
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        extraInfo =  [PubgLoad new];
        [extraInfo initTapGes];
        [extraInfo tapIconView];
    });
}
- (void)load{
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(screenshots) name:UIApplicationUserDidTakeScreenshotNotification object:nil];
    UIScreen * sc = [UIScreen mainScreen];
    if (@available(iOS 11.0, *)) {
        if (sc.isCaptured) {
            NSLog(@"正在录制~~~~~~~~~%d",sc.isCaptured);
            [self screenshotss];
        }
    } else {
        // Fallback on earlier versions
    }

    if (@available(iOS 11.0, *)) {
    //检测到当前设备录屏状态发生变化
            [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(screenshotss) name:UIScreenCapturedDidChangeNotification  object:nil];
        } else {
            // Fallback on earlier versions
        }

}
-(void) screenshotss
{
    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"刚某侠提示" message:@"禁止截图录屏\n你的操作已被记录＼n游戏即将退出\n截图录屏外传将删除卡密" preferredStyle:UIAlertControllerStyleAlert];

     [alertCtrl addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    exit(0);
    exit(0);
     }]];

     [[[[UIApplication sharedApplication] windows] objectAtIndex:0].rootViewController presentViewController:alertCtrl animated:YES completion:nil];
}
-(void)initTapGes
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    tap.numberOfTapsRequired = 3;//点击次数
    tap.numberOfTouchesRequired = 3;//手指数
    [[JHPP currentViewController].view addGestureRecognizer:tap];
    [tap addTarget:self action:@selector(tapIconView)];
}

-(void)tapIconView
{
    JHDragView *view = [[JHPP currentViewController].view viewWithTag:100];
    if (!view) {
        view = [[JHDragView alloc] init];
        view.tag = 100;
        [[JHPP currentViewController].view addSubview:view];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onConsoleButtonTapped:)];
        tap.numberOfTapsRequired = 1;
        [view addGestureRecognizer:tap];
    }
    
    if (!MenDeal) {
        view.hidden = NO;
    } else {
        view.hidden = YES;
    }
    
    MenDeal = !MenDeal;
}

// JR_Search_Type_ULong   //U64     uint64_t
// JR_Search_Type_Double  //Double  Double
// JR_Search_Type_SLong   //I64     SInt64
// JR_Search_Type_Float   //Float   Float
// JR_Search_Type_UInt    //U32     uint32_t
// JR_Search_Type_SInt    //I32     SInt32
// JR_Search_Type_UShort  //U16     uint16_t
// JR_Search_Type_SShort  //I16     SInt16
// JR_Search_Type_UByte   //U8      uint8_t
// JR_Search_Type_SByte   //I8      SInt8

-(void)onConsoleButtonTapped:(id)sender
{
//    总菜单开始=============
    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
    [alert addTimerToButtonIndex:0 reverse:YES];
    //  总菜单单个功能1 无后




    [alert addButton:@"出生岛开启防后开范围" actionBlock:^{
         JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                      AddrRange range = (AddrRange){0x100000000,0x160000000};
                      uint32_t search = 134914;
                      engine.JRScanMemory(range, &search, JR_Search_Type_SInt);
                      vector<void*>results = engine.getAllResults();
                      uint32_t modify = 9;
                      for(int i = 0; i < results.size(); i++){
                             engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_SInt);

        }

    }];

    [alert addButton:@"无后" actionBlock:^{
        

        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x160000000};
        uint64_t search = 7815225705762155637;
        engine.JRScanMemory(range, &search, JR_Search_Type_ULong);
        vector<void*>results = engine.getAllResults();
        uint64_t modify = 781522570416069018;
        for(int i = 0; i < results.size(); i++){
            if(i == 5)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_ULong);
        }
        
    }];
    //  总菜单单个功能2 上色

    
    
    //子菜单开始-总菜单里面添加一个子菜单 处理器上色  里面包含好几个功能
    [alert addButton:@"范围专区" actionBlock:^{
        SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
        [alert addTimerToButtonIndex:0 reverse:YES];
 [alert addButton:@"范围10万" actionBlock:^{

     JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
          AddrRange range = (AddrRange){0x100000000,0x160000000};
          float search = 9.203507e-05;
          engine.JRScanMemory(range, &search, JR_Search_Type_Float);
          float search1 = 28;
          engine.JRNearBySearch(0x20,&search1,JR_Search_Type_Float);
          vector<void*>results = engine.getAllResults();
          float modify = 100000;
          for(int i = 0; i < results.size();i++){
              if(i == 1)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
              if(i == 3)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);

         }


     }];
           [alert addButton:@"范围20万" actionBlock:^{

               JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    float search = 9.203507e-05;
                    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
                    float search1 = 28;
                    engine.JRNearBySearch(0x20,&search1,JR_Search_Type_Float);
                    vector<void*>results = engine.getAllResults();
                    float modify = 500000;
                    for(int i = 0; i < results.size();i++){
                        if(i == 1)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
                        if(i == 3)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);

                   }


               }];
           [alert addButton:@"范围30万" actionBlock:^{

               JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                    AddrRange range = (AddrRange){0x100000000,0x160000000};
                    float search = 9.203507e-05;
                    engine.JRScanMemory(range, &search, JR_Search_Type_Float);
                    float search1 = 28;
                    engine.JRNearBySearch(0x20,&search1,JR_Search_Type_Float);
                    vector<void*>results = engine.getAllResults();
                    float modify = 300000;
                    for(int i = 0; i < results.size();i++){
                        if(i == 1)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
                        if(i == 3)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);

                   }


               }];
        [alert addButton:@"范围50万" actionBlock:^{

                      JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                           AddrRange range = (AddrRange){0x100000000,0x160000000};
                           float search = 9.203507e-05;
                           engine.JRScanMemory(range, &search, JR_Search_Type_Float);
                           float search1 = 28;
                           engine.JRNearBySearch(0x20,&search1,JR_Search_Type_Float);
                           vector<void*>results = engine.getAllResults();
                           float modify = 500000;
                           for(int i = 0; i < results.size();i++){
                               if(i == 1)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
                               if(i == 3)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);

                          }


                      }];
        [alert addButton:@"范围80万" actionBlock:^{

                      JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
                           AddrRange range = (AddrRange){0x100000000,0x160000000};
                           float search = 9.203507e-05;
                           engine.JRScanMemory(range, &search, JR_Search_Type_Float);
                           float search1 = 28;
                           engine.JRNearBySearch(0x20,&search1,JR_Search_Type_Float);
                           vector<void*>results = engine.getAllResults();
                           float modify = 800000;
                           for(int i = 0; i < results.size();i++){
                               if(i == 1)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
                               if(i == 3)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);

                          }


                      }];
        [alert showSuccess:@"刚某侠" subTitle:@"感谢使用" closeButtonTitle:@"取消" duration:0];
           }];
//    [alert addButton:@"上色" actionBlock:^{
//        SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
//        [alert addTimerToButtonIndex:0 reverse:YES];
//        [alert addButton:@"头发上色" actionBlock:^{
//            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//            AddrRange range = (AddrRange){0x100000000,0x160000000};
//            float search = 0.2;
//            engine.JRScanMemory(range, &search, JR_Search_Type_Float);
//            float search1 = 1;
//            engine.JRNearBySearch(0x50,&search1,JR_Search_Type_Float);
//            float search2 = 1;
//            engine.JRScanMemory(range, &search2, JR_Search_Type_Float);
//            vector<void*>results = engine.getAllResults();
//            float modify = 999;
//            for(int i = 0;i<results.size();i++){
//                engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
//            }
//
//        }];
//        [alert addButton:@"人物上色" actionBlock:^{
//            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//            AddrRange range = (AddrRange){0x100000000,0x160000000};
//            float search = 0.08152;
//            engine.JRScanMemory(range, &search, JR_Search_Type_Float);
//            float search1 = 0.2;
//            engine.JRNearBySearch(0x500,&search1,JR_Search_Type_Float);
//            float search2 = 0.2;
//            engine.JRScanMemory(range, &search2, JR_Search_Type_Float);
//            vector<void*>results = engine.getAllResults();
//            float modify = 0.8;
//            for(int i = 0;i<results.size();i++){
//                engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
//            }
//
//        }];
//        [alert addButton:@"巨人(拉回)" actionBlock:^{
//            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//            AddrRange range = (AddrRange){0x100000000,0x160000000};
//            double search = 1.613775153007164e-314;
//            engine.JRScanMemory(range, &search, JR_Search_Type_Double);
//            float search1 = 1;
//            engine.JRNearBySearch(0x50,&search1,JR_Search_Type_Float);
//            float search2 = 1;
//            engine.JRScanMemory(range, &search2, JR_Search_Type_Float);
//            vector<void*>results = engine.getAllResults();
//            float modify = 8;
//            for(int i = 0;i<results.size();i++){
//                engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
//            }
//
//        }];
//        [alert addButton:@"加速" actionBlock:^{
//            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//            AddrRange range = (AddrRange){0x100000000,0x160000000};
//            double search = 6.798361019377807e-06;
//            engine.JRScanMemory(range, &search, JR_Search_Type_Double);
//            float search1 = 0.0005;
//            engine.JRNearBySearch(0x50,&search1,JR_Search_Type_Float);
//            float search2 = 0.0005;
//            engine.JRScanMemory(range, &search2, JR_Search_Type_Float);
//            vector<void*>results = engine.getAllResults();
//            float modify = 0.25;
//            for(int i = 0;i<results.size();i++){
//                engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
//            }
//
//        }];
//        [alert addButton:@"头发上色" actionBlock:^{
//            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//            AddrRange range = (AddrRange){0x100000000,0x160000000};
//            float search = 0.2;
//            engine.JRScanMemory(range, &search, JR_Search_Type_Float);
//            float search1 = 1;
//            engine.JRNearBySearch(0x50,&search1,JR_Search_Type_Float);
//            float search2 = 1;
//            engine.JRScanMemory(range, &search2, JR_Search_Type_Float);
//            vector<void*>results = engine.getAllResults();
//            float modify = 999;
//            for(int i = 0;i<results.size();i++){
//                engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
//            }
//
//        }];
//
//        [alert showSuccess:@"刚某侠" subTitle:@"感谢使用" closeButtonTitle:@"取消" duration:0];
//           }];
     //子菜单结束
    
    [alert showSuccess:@"刚某侠" subTitle:@"感谢使用" closeButtonTitle:@"取消" duration:0];
//    总菜单结束=============
    
    /*[alertCtrl addAction:[UIAlertAction actionWithTitle:@"镜防" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x00000000,0x160000000};
        uint64_t search = 6874028368030887269;
        engine.JRScanMemory(range, &search, JR_Search_Type_ULong);
        vector<void*>results = engine.getAllResults();
        uint64_t modify = 0;
        for(int i = 0;i < results.size();i++){
            if(i == 0)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_ULong);
        }
    }]];*/
    
    
//    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"范围-20w" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
//        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//        AddrRange range = (AddrRange){0x100000000,0x160000000};
//        float search = 9.203507e-05;
//        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
//        float search1 = 28;
//        engine.JRNearBySearch(0x20,&search1,JR_Search_Type_Float);
//        vector<void*>results = engine.getAllResults();
//        float modify = 200000;
//        for(int i = 0;i<results.size();i++){
//            if(i == 1)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
//        }
//    }]];
    
   /* [alertCtrl addAction:[UIAlertAction actionWithTitle:@"范围-60w" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = (AddrRange){0x100000000,0x160000000};
        float search = 9.203507e-05;
        engine.JRScanMemory(range, &search, JR_Search_Type_Float);
        float search1 = 28;
        engine.JRNearBySearch(0x20,&search1,JR_Search_Type_Float);
        vector<void*>results = engine.getAllResults();
        float modify = 600000;
        for(int i = 0;i<results.size();i++){
            if(i == 1)engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float);
        }
    }]];*/
    
//
//    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"内存防请配合端口" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
//        JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
//        AddrRange range = (AddrRange){0x100000000,0x160000000};
//        uint32_t search = 67109633;
//        engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
//        vector<void*>results = engine.getAllResults();
//        uint32_t modify = 0;
//        for(int i = 0; i < results.size(); i++){
//            engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_UInt);
//        }
//    }]];
    
}


@end
