//
//  NetWorkingApiClient.m
//  BSPHPOC
//
//  Created by MRW on 2016/12/14.
//  Copyright © 2016年 xiaozhou. All rights reserved.
//

#import "NetWorkingApiClient.h"

static NetWorkingApiClient *netWorkingClient = nil;

@implementation NetWorkingApiClient

+ (NetWorkingApiClient *)sharedNetWorkingApiClient{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        netWorkingClient = [[NetWorkingApiClient alloc] initWithBaseURL:[NSURL URLWithString:@""]];
        netWorkingClient.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
        
        //设置返回原生状态数据：返回NSData类型
        netWorkingClient.responseSerializer = [AFHTTPResponseSerializer serializer];

    });
    return netWorkingClient;
}

@end
