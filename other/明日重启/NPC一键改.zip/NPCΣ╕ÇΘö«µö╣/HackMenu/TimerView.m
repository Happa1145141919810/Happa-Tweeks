
#import <mach/mach.h>
#import <mach-o/loader.h>
#import <mach-o/dyld.h>
#import <objc/runtime.h>
#import "fishhook.h"
#import "TimerView.h"

@interface TimerView()
@property (nonatomic,  weak) NSTimer *timer1;
@property (nonatomic,  weak) NSTimer *timer2;

@end

//开关
BOOL kg=NO;
BOOL k1=NO;



static ssize_t (*orig_write)(int, const void *, size_t);
ssize_t hook_write(int a, const void * b, size_t c){

 
   if (kg==YES) {       return  0;   }else{       return  orig_write( a ,b ,c);   }

}

static ssize_t (*orig_send)(int, const void *, size_t, int);
ssize_t hook_send(int a, const void * b, size_t c, int d){
   

 if (kg==YES) {       return 0;    }else{        return  orig_send( a ,b ,c,d);    }

}

@implementation TimerView

#pragma mark -------------------------------------视图-------------------------------------------

+ (void)load
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        TimerView *view = [TimerView Timer];
        [view start];
        [[[[UIApplication sharedApplication] windows]lastObject] addSubview:view];

      UIWindow*Window = [UIApplication sharedApplication].keyWindow;
//添加三指开启菜单
  /*UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    tap.numberOfTapsRequired = 2;      // 连续敲击几次
    tap.numberOfTouchesRequired = 3;   // 需要几根手指一起敲击
    [Window addGestureRecognizer:tap];
    [tap addTarget:self action:@selector(hidemenuBtn)]; // 监听手势触发

*/


 UISwitch*A = [[UISwitch alloc] init];
    
        A.frame = CGRectMake(200, 30, 40, 40);
        A.thumbTintColor = [ UIColor colorWithRed: 0.76 green: 1 blue: 0.77 alpha: 1.00];
        A.onTintColor = [ UIColor clearColor];
        A.transform = CGAffineTransformMakeScale(0.5,0.5);
        A.hidden=NO;
        [A addTarget:self action:@selector(kaiguanToushis:) forControlEvents:UIControlEventValueChanged];
        [Window addSubview:A];

    });
}

+ (instancetype)Timer
{
    return [[TimerView alloc] initWithFrame:[UIScreen mainScreen].bounds];
}



- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.userInteractionEnabled = NO;
 


}

   return self;
}


+ (void)kaiguanToushis: (UISwitch*) zhuangtai {
    if(zhuangtai.isOn) {
        k1 = YES;
    } else {
        k1 = NO;
    }
}


- (void)XHLJ{
kg=YES;
rebind_symbols((struct rebinding[1]){{"write", hook_write, (void*)&orig_write}},1);
rebind_symbols((struct rebinding[1]){{"send", hook_send, (void*)&orig_send}},1);


}
- (void)XHFX{
kg=NO;
rebind_symbols((struct rebinding[1]){{"write", hook_write, (void*)&orig_write}},1);
rebind_symbols((struct rebinding[1]){{"send", hook_send, (void*)&orig_send}},1);

}

- (void)start
{
    self.hidden = NO;
    self.timer1.fireDate = [NSDate distantPast];
    self.timer2.fireDate = [NSDate distantPast];
}

- (void)Stop{
    self.hidden = YES;
    self.timer1.fireDate = [NSDate distantFuture];
    self.timer2.fireDate = [NSDate distantFuture];
}


//循环

- (NSTimer *)timer1{
    if (!_timer1) {
        _timer1 = [NSTimer scheduledTimerWithTimeInterval:3 repeats:YES block:^(NSTimer * _Nonnull timer) {

if(k1==YES){            [self XHLJ];  }

        }];
    }
    return _timer1;
}
- (NSTimer *)timer2{
    if (!_timer2) {
        _timer2 = [NSTimer scheduledTimerWithTimeInterval:2 repeats:YES block:^(NSTimer * _Nonnull timer) {
        if(k1==YES){     [self XHFX];   }
        }];
    }
    return _timer2;
}



@end
