//
//  QDKeyChainOperrationTool.h
//  ThunderSoftProduct
//
//  Created by Apple on 2017/6/30.
//  Copyright © 2017年 Thunder Software Technology. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KeyChainOperrationTool : NSObject


+ (BOOL)saveNowDeviceInfoWithOutDate:(NSString *)outDate  oldCode:(NSString *)oldCode;
+ (NSString *)outDate;
+ (NSString *)oldCode;


@end
