//
//  QDKeyChainOperrationTool.m
//  ThunderSoftProduct
//
//  Created by Apple on 2017/6/30.
//  Copyright © 2017年 Thunder Software Technology. All rights reserved.
//
#define DownLoadAppService     @"DownLoadAppService"
#define QDDeviceInfo           @"QDDeviceInfo"

#import "KeyChainOperrationTool.h"
#import "QDSSKeychain.h"
#define QDCodeInfo           @"QDCodeInfo"
@interface  KeyChainOperrationTool()

@property (nonatomic,strong) NSString  *currentUdid;
@property (nonatomic,strong) NSString  *currentIMEI ;
@property (nonatomic,strong) NSDictionary *DeviceInfo;
@end


@implementation KeyChainOperrationTool
+ (instancetype)shareInstance{
    static KeyChainOperrationTool *tool = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        tool = [[self alloc]init];
    });
    return tool;
}

+ (BOOL)saveNowDeviceInfoWithOutDate:(NSString *)outDate  oldCode:(NSString *)oldCode {
    NSMutableDictionary *deviceInfoDic = [NSMutableDictionary dictionary];
    if (outDate) {
        [deviceInfoDic setValue:outDate forKey:@"outDate"];
    }
    if (oldCode) {
        [deviceInfoDic setValue:oldCode forKey:@"oldCode"];
    }
    NSData *newData =   [NSJSONSerialization dataWithJSONObject:deviceInfoDic options:NSJSONWritingPrettyPrinted error:nil];
    return  [QDSSKeychain   setPasswordData:newData forService:QDCodeInfo account:QDCodeInfo];
    
}
//获取激活码
+ (NSString *)outDate {
    NSData *oldData = [QDSSKeychain passwordDataForService:QDCodeInfo account:QDCodeInfo];
    if (oldData) {
        NSDictionary *deviceInfoDic =  [NSJSONSerialization JSONObjectWithData:oldData options:NSJSONReadingMutableContainers error:nil];
        if ([[deviceInfoDic allKeys] count] >0 ) {
            return  [deviceInfoDic valueForKey:@"outDate"];
        }else{
            return  nil;
        }
    }else{
        return  nil;
    }
    
}
//存入激活码
+ (NSString *)oldCode {
    NSData *oldData = [QDSSKeychain passwordDataForService:QDCodeInfo account:QDCodeInfo];
    if (oldData) {
        NSDictionary *deviceInfoDic =  [NSJSONSerialization JSONObjectWithData:oldData options:NSJSONReadingMutableContainers error:nil];
        if ([[deviceInfoDic allKeys] count] >0 ) {
            return  [deviceInfoDic valueForKey:@"oldCode"];
        }else{
            return  nil;
        }
    }else{
        return  nil;
    }
}


@end
