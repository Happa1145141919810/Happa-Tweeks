//
//  DLGMemEntry.m
//  memui
//
//  Created by Liu Junqi on 4/23/18.
//  Copyright © 2018 DeviLeo. All rights reserved.
//[webView removeFromSuperview];

#import "DLGMemEntry.h"
#import "DLGMem.h"
#import "LRKeychain.h"
#import <WebKit/WebKit.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <dlfcn.h>
#import <mach-o/dyld.h>
#import <AVFoundation/AVFoundation.h>
#import <AdSupport/ASIdentifierManager.h>
#import "CaptainHook.h"
#import "defines.h"
#import "MF_Base64Additions.h"
#import "NSDictionary+StichingStringkeyValue.h"
#import "NSString+MD5.h"
#import "NSString+URLCode.h"
#import "UserInfoManager.h"
#import "Config.h"
#import "DES3Utill.h"
#import "UIAlertView+Blocks.h"

#import <Foundation/Foundation.h>
#import "SCLAlertView.h"
#import "copyright.h"
#import "NSEtcHosts.h"
@interface VerifyEntry ()<UIAlertViewDelegate>

@end
@implementation DLGMemEntry
//配置
static void __attribute__((constructor)) entry()
{
    if (/* DISABLES CODE */ (1))
    {dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^
        {
            [NSObject Bsphp];
         
        });
    } else {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^
            {
               [NSObject souye];
            });
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^
        {
           [[[DLGMem alloc] init] launchDLGMem];
        });
    }
}

@end
@implementation VerifyEntry


+ (instancetype)MySharedInstance
{
    static VerifyEntry *sharedSingleton;
    
    if (!sharedSingleton)
    {
        static dispatch_once_t oncePPM;
        dispatch_once(&oncePPM, ^
                      {
                          sharedSingleton = [[VerifyEntry alloc] init];
                      });
    }
    
    return sharedSingleton;
}


- (NSString*)getIDFA
{
    ASIdentifierManager *as = [ASIdentifierManager sharedManager];
    return as.advertisingIdentifier.UUIDString;
}

- (void)showAlertMsg:(NSString *)show error:(BOOL)error
{
    DisPatchGetMainQueueBegin();
    
    NSString *title = @"";
    if (YES == error)
    {
        title = @"信息";
    }
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:show delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil, nil];
    [alert show];
    
    DisPatchGetMainQueueEnd();
}

- (void)startProcessActivateProcess:(NSString *)code finish:(void (^)(NSDictionary *done))finish
{
    
    
    
    NSString * strmutualkey = NULL;
    strmutualkey  = [DES3Utill decrypt:LD_KEY gkey:LD_AAAA];
    
    NSString * strhost = NULL;
    strhost  = [DES3Utill decrypt:LD_API gkey:LD_AAAA];
    
    
    
    //授权码验证
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    param[@"api"] = @"login.ic";
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd#HH:mm:ss"];
    NSString *dateStr = [dateFormatter stringFromDate:[NSDate date]];
    param[@"BSphpSeSsL"] = [dateStr MD5Digest];
    NSDate *date = [NSDate date];
    NSTimeZone * zone = [NSTimeZone systemTimeZone];
    NSInteger interval = [zone secondsFromGMTForDate:date];
    NSDate * nowDate = [date dateByAddingTimeInterval:interval];
    NSString *nowDateStr = [[nowDate description] stringByReplacingOccurrencesOfString:@" +0000" withString:@""];
    param[@"date"] = nowDateStr;
    param[@"md5"] = @"";
    param[@"mutualkey"] = strmutualkey;
    param[@"icid"] = code;
    param[@"icpwd"] = @"";
    param[@"key"] = [self getIDFA];
    param[@"maxoror"] = [self getIDFA];
    [NetTool Post_AppendURL:strhost myparameters:param mysuccess:^(id responseObject)
     {
         NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
         if (dict)
         {
             NSString *dataString = dict[@"response"][@"data"];
             NSRange range = [dataString rangeOfString:@"|1081|"];
             
             if (range.location != NSNotFound)
             {
                 NSString *activationDID = [[NSUserDefaults standardUserDefaults]objectForKey:@"activationDeviceID"];
                 if (![activationDID isEqualToString:code])
                 {
                     [[NSUserDefaults standardUserDefaults] setObject:code forKey:@"activationDeviceID"];
                 }
                 
                 UserInfoManager *manager =   [UserInfoManager shareUserInfoManager];
                 NSArray *arr = [dataString componentsSeparatedByString:@"|"];
                 if (arr.count >= 6)
                 {
                     manager.state01 = arr[0];
                     manager.state1081 = arr[1];
                     manager.deviceID = arr[2];
                     manager.returnData = arr[3];
                     manager.expirationTime = arr[4];
                     manager.activationTime = arr[5];
                     if(manager.deviceID!=[self getIDFA]){
                          manager.state01 = nil;
                         manager.state1081 = nil;
                         manager.deviceID = nil;
                         manager.returnData = nil;
                         manager.expirationTime = nil;
                         manager.activationTime = nil;
                         [self processActivate];
                     }else{
                     }
                     DisPatchGetMainQueueBegin();
                     NSString *showMsg = [NSString stringWithFormat:@"过期时间: %@", arr[4]];
                     [UIAlertView showWithTitle:@"验证成功 重启应用生效" message:showMsg cancelButtonTitle:@"确定" otherButtonTitles:nil tapBlock:nil];
                     DisPatchGetMainQueueEnd();
                      
                 }
             }
             else
             {
                 NSString *messageStr = dict[@"response"][@"data"];
                 UserInfoManager *manager =   [UserInfoManager shareUserInfoManager];
                 manager.state01 = nil;
                 manager.state1081 = nil;
                 manager.deviceID = nil;
                 manager.returnData = nil;
                 manager.expirationTime = nil;
                 manager.activationTime = nil;
                 [self showAlertMsg:messageStr error:YES];
                 [self processActivate];
                
             }
         }
     } myfailure:^(NSError *error)
     {
         [self processActivate];
     }];

}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *CONFIRM = @"激活";
    
    NSString *btnTitle = [alertView buttonTitleAtIndex:buttonIndex];
    if (YES == [btnTitle isEqualToString:CONFIRM])
    {
        UITextField *tf = [alertView textFieldAtIndex:0];
        if (nil == tf.text || 0 == tf.text.length)
        {
            [self processActivate];
            return ;
        }
        
        [self startProcessActivateProcess:tf.text finish:nil];
    }
    else
    {
        [self processActivate];
    }
}

- (void)processActivate
{
    
   NSString *CONFIRM = @"激活";
   
   NSString *CANCEL = @"取消";
    
    
   UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"提示" delegate:self cancelButtonTitle:CANCEL otherButtonTitles:CONFIRM, nil];

    
    
    
    [alert setAlertViewStyle:UIAlertViewStylePlainTextInput];
    UITextField *txtName = [alert textFieldAtIndex:0];
    txtName.placeholder = @"请在30秒内输入你的激活码";
    [alert show];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(40 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        exit(0);});
}

@end

@interface iosgods : NSObject

@end

@implementation iosgods

-(id)init
{
    if ((self = [super init]))
    {
    }
    
    return self;
}
//获取当前显示的VC
- (UIViewController *)getCurrentVC{
    //获取默认window
    UIWindow *window = [[UIApplication sharedApplication] keyWindow];
    if(window.windowLevel != UIWindowLevelNormal){
        NSArray *windows = [[UIApplication sharedApplication]windows];
        for(UIWindow *tmpWindow in windows){
            if (tmpWindow.windowLevel == UIWindowLevelNormal) {
                window = tmpWindow;
                break;
            }
        }
    }
    
    //获取window的根视图
    UIViewController *currentVC = window.rootViewController;
    while (currentVC.presentedViewController) {
        currentVC = currentVC.presentedViewController;
    }
    if ([currentVC isKindOfClass:[UITabBarController class]]) {
        currentVC = [(UITabBarController*)currentVC selectedViewController];
    }
    if ([currentVC isKindOfClass:[UINavigationController class]]) {
        currentVC = [(UINavigationController*)currentVC visibleViewController];
    }
    return currentVC;
}
@end

static NSString *MUFENGKEY  =   @"MUFENG";
@interface JD : UIViewController<WKNavigationDelegate>

@end

@implementation JD
static JD *jd = nil;
+ (JD *)sharedInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (jd == nil) {
            jd = [[self alloc] init];
        }
    });
    return jd;
}
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation
{
    

     //判断网页文字2️⃣2️⃣2️⃣2️⃣2️⃣2️⃣2️⃣2️⃣2️⃣2️⃣
    NSString *doc = @"document.body.outerHTML";
    [webView evaluateJavaScript:doc
              completionHandler:^(id _Nullable htmlStr, NSError * _Nullable error)
    {
                  if (error)
                  {
                      NSLog(@"JSError:%@",error);
                     
                  }
                  NSLog(@"html:%@",htmlStr);

        if ([(NSString *)htmlStr containsString:@"您无权限使用"])
                  {
                      NSString    *str1   =@"您无权限使用";
                      if ([htmlStr containsString:str1]) {
                          NSLog(@"str1包含str2");
                          NSString    *udid   =   [[UIDevice currentDevice] identifierForVendor].UUIDString;
                          [LRKeychain addKeychainData:udid forKey:MUFENGKEY];
                         
                          
                          SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
                          [alert addTimerToButtonIndex:0 reverse:YES];//yes为倒计时NO为正数
                          [alert addButton:@"登陆" actionBlock:^
                          {
                              [NSObject denglu];
                          }];
                          
                          [alert addButton:@"注册" actionBlock:^
                          {
                              [NSObject zhuche];
                          }];
                          [alert showWaiting:@"登陆VIP验证" subTitle:@"请先登陆论坛账号" closeButtonTitle:nil duration:5];
//                          [NSObject denglu];
                      } else {
                          NSLog(@"str1不包含str2");
                      }
                      
                   
                    }
        if ([(NSString *)htmlStr containsString:@"欢迎注册登陆"])
                  {
                            NSString    *str1   =@"欢迎注册登陆";
                            if ([htmlStr containsString:str1]) {
                                NSLog(@"str1包含str2");
                                NSString    *udid   =   [[UIDevice currentDevice] identifierForVendor].UUIDString;
                                [LRKeychain addKeychainData:udid forKey:MUFENGKEY];
                                
                                
                                SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
                                [alert addTimerToButtonIndex:0 reverse:YES];//yes为倒计时NO为正数
                                [alert addButton:@"登陆" actionBlock:^
                                {
                                    [NSObject denglu];
                                }];
                                
                                [alert addButton:@"注册" actionBlock:^
                                {
                                    [NSObject zhuche];
                                }];
                                [alert showWaiting:@"登陆VIP验证" subTitle:@"请先登陆论坛账号" closeButtonTitle:nil duration:5];
    //                          [NSObject denglu];
                            } else {
                                NSLog(@"str1不包含str2");
                            }
                            
                        
                        }
        if ([(NSString *)htmlStr containsString:@"尊敬的VIP用户"])
                  {
                   NSString    *udid   =   [[UIDevice currentDevice] identifierForVendor].UUIDString;
                   [LRKeychain addKeychainData:udid forKey:MUFENGKEY];
//                 [webView removeFromSuperview];
                    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
                    NSRange vip1 = [htmlStr rangeOfString:@"44"];
                    NSRange vip2 = [htmlStr rangeOfString:@"55"];
                    NSRange range = NSMakeRange(vip1.location + vip1.length, vip2.location - vip1.location - vip1.length);
                    NSString *vipday = [htmlStr substringWithRange:range];
                    [alert addButton:vipday actionBlock:^
                    {
                        [NSObject shebei];
                        
                    }];
                      [alert addButton:@"访问官网" actionBlock:^
                    {
                          NSString *urlStr = [NSString stringWithFormat:@"https://iosgods.cn"];
                          [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlStr]];
                          
                      }];
                    [alert addButton:@"进入游戏"  actionBlock:^
                                        {
                                           
                        [NSObject shebei];
                        [webView removeFromSuperview];
                                            
                                        }];
                    [alert addButton:@"续费/购买"  actionBlock:^
                    {
                        [NSObject goumai];
                        [webView removeFromSuperview];
//
                        
                    }];
                   //截取htmlStr中66~99的字符串为result
                    NSRange name1 = [htmlStr rangeOfString:@"66"];
                    NSRange name2 = [htmlStr rangeOfString:@"99"];
                    NSRange name = NSMakeRange(name1.location + name1.length, name2.location - name1.location - name1.length);
                    NSString *member = [htmlStr substringWithRange:name];
                    [alert showInfo:member subTitle:@"尊敬的VIP用户感谢使用" closeButtonTitle:nil duration:10];
                    
                }
        if ([(NSString *)htmlStr containsString:@"当前状态普通"])
                  {
            NSString    *str1   =@"当前状态普通";
            if ([htmlStr containsString:str1]) {
                NSLog(@"str1包含str2");

            
              
                SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
                NSRange vip1 = [htmlStr rangeOfString:@"44"];
                NSRange vip2 = [htmlStr rangeOfString:@"55"];
                NSRange range = NSMakeRange(vip1.location + vip1.length, vip2.location - vip1.location - vip1.length);
                NSString *vipday = [htmlStr substringWithRange:range];
                NSString    *udid   =   [[UIDevice currentDevice] identifierForVendor].UUIDString;
                NSRange name1 = [htmlStr rangeOfString:@"66"];
                NSRange name2 = [htmlStr rangeOfString:@"99"];
                NSRange name = NSMakeRange(name1.location + name1.length, name2.location - name1.location - name1.length);
                NSString *member = [htmlStr substringWithRange:name];
                [LRKeychain addKeychainData:udid forKey:MUFENGKEY];
               [alert addButton:vipday actionBlock:^
                                   {
                                       
                                       
                                   }];
                                     [alert addButton:@"访问官网" actionBlock:^
                                   {
                                         NSString *urlStr = [NSString stringWithFormat:@"https://iosgods.cn"];
                                         [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlStr]];
                                         
                                     }];
                                   [alert addButton:@"购买VIP进游戏"  actionBlock:^
                                                       {
                                                           // exit(0);
                                       [NSObject goumai];
                                                           
                                                       }];
                                   [alert addButton:@"关闭提示"  actionBlock:^
                                   {
                                       // exit(0);
               //
                                       
                                   }];
                                  
                                   [alert showInfo:member subTitle:@"您未购买VIP或已过期\n购买后重启游戏即可" closeButtonTitle:nil duration:10];
            } else {
                NSLog(@"str1不包含str2");
            }


          }
        if ([(NSString *)htmlStr containsString:htmlStr])
                  {
                      if ([htmlStr containsString:@"其他设备"])
                      {
                          if([htmlStr containsString:@"本机退出登录"])
                          {
                              SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
                              alert.showAnimationType = SCLAlertViewHideAnimationSlideOutToCenter;
                              alert.hideAnimationType = SCLAlertViewHideAnimationSlideOutFromCenter;
                              [alert showWaiting:self title:@"设备验证"
                                       subTitle:@"登录的设备过多\n请往下翻\n双击退出其他设备\n本机设备不需要退出"
                                 closeButtonTitle:nil duration:3.0f];

                          }//同时包含退出本机

                      }//匹配两个条件满足
                      else
                      {
                          if([htmlStr containsString:@"本机退出登录"])
                          {
                              if([htmlStr containsString:@"本机退出登录"])
                              {
                                  SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
                                  alert.showAnimationType = SCLAlertViewHideAnimationSlideOutToCenter;
                                  alert.hideAnimationType = SCLAlertViewHideAnimationSlideOutFromCenter;
                                  [alert showWaiting:self title:@"设备验证完毕"
                                           subTitle:@"如频繁同时登陆过多\n将自动禁封论坛账号\n后果自负-不接受申诉"
                                     closeButtonTitle:nil duration:3.0f];
                                  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                                      [webView removeFromSuperview];
                                    
                                  });
                                 

                              }//同时包含退出本机

                          }
                          

                      }//否则关闭网页

                  }//设备提示
        
       
        

        
    }
    ] ;

}





/**清除缓存和cookie*/

- (void)cleanCacheAndCookie
{
    
    //清除cookies
    
    NSHTTPCookie *cookie;
    
    NSHTTPCookieStorage *storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    
    for (cookie in [storage cookies]){
        
        [storage deleteCookie:cookie];
        
    }
    
    //清除UIWebView的缓存
    
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
    
    NSURLCache * cache = [NSURLCache sharedURLCache];
    
    [cache removeAllCachedResponses];
    
    [cache setDiskCapacity:0];
    
    [cache setMemoryCapacity:0];
    
}
@end
@implementation NSObject (hook)
//功能●●●●●●●●
-(BOOL)souye
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"aaaaaaaaaaaaaa");
        UIWindow    *window =   [[UIApplication sharedApplication] keyWindow];
        WKWebView   *webView    =   [[WKWebView alloc] initWithFrame:window.bounds];
        webView.navigationDelegate  =   [JD sharedInstance];
       
        NSString    *udid   =   [[UIDevice currentDevice] identifierForVendor].UUIDString;
        if ([[LRKeychain getKeychainDataForKey:MUFENGKEY] isEqualToString:udid])
        {
            [webView loadRequest:[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"https://iosgods.cn"]]];
        }else
        {
           [NSObject goumai];
        }
        [window addSubview:webView];
    });
}
-(BOOL)shebei
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"aaaaaaaaaaaaaa");
        UIWindow    *window =   [[UIApplication sharedApplication] keyWindow];
        WKWebView   *webView    =   [[WKWebView alloc] initWithFrame:window.bounds];
        webView.navigationDelegate  =   [JD sharedInstance];
       
        NSString    *udid   =   [[UIDevice currentDevice] identifierForVendor].UUIDString;
        if ([[LRKeychain getKeychainDataForKey:MUFENGKEY] isEqualToString:udid])
        {
            [webView loadRequest:[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"https://iosgods.cn/index.php?/settings/devices/"]]];
        }else
        {
            [webView loadRequest:[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"https://iosgods.cn/index.php?/settings/devices/"]]];
        }
        [window addSubview:webView];
    });
}
-(BOOL)denglu
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"aaaaaaaaaaaaaa");
        UIWindow    *window =   [[UIApplication sharedApplication] keyWindow];
        WKWebView   *webView    =   [[WKWebView alloc] initWithFrame:window.bounds];
        webView.navigationDelegate  =   [JD sharedInstance];
       
        NSString    *udid   =   [[UIDevice currentDevice] identifierForVendor].UUIDString;
        if ([[LRKeychain getKeychainDataForKey:MUFENGKEY] isEqualToString:udid])
        {
            [webView loadRequest:[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"https://iosgods.cn/index.php?/login/"]]];
        }else
        {
            [webView loadRequest:[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"https://iosgods.cn/index.php?/login/"]]];
        }
        [window addSubview:webView];
    });
}
-(BOOL)zhuche
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"aaaaaaaaaaaaaa");
        UIWindow    *window =   [[UIApplication sharedApplication] keyWindow];
        WKWebView   *webView    =   [[WKWebView alloc] initWithFrame:window.bounds];
        webView.navigationDelegate  =   [JD sharedInstance];
       
        NSString    *udid   =   [[UIDevice currentDevice] identifierForVendor].UUIDString;
        if ([[LRKeychain getKeychainDataForKey:MUFENGKEY] isEqualToString:udid])
        {
            [webView loadRequest:[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"https://iosgods.cn/index.php?/register/"]]];
        }else
        {
            [webView loadRequest:[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"https://iosgods.cn/index.php?/register/"]]];
        }
        [window addSubview:webView];
    });
}
-(BOOL)goumai
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"aaaaaaaaaaaaaa");
        UIWindow    *window =   [[UIApplication sharedApplication] keyWindow];
        WKWebView   *webView    =   [[WKWebView alloc] initWithFrame:window.bounds];
        webView.navigationDelegate  =   [JD sharedInstance];
       
        NSString    *udid   =   [[UIDevice currentDevice] identifierForVendor].UUIDString;
        if ([[LRKeychain getKeychainDataForKey:MUFENGKEY] isEqualToString:udid])
        {
            [webView loadRequest:[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"https://iosgods.cn/index.php?/clients/credit/"]]];
        }else
        {
            [webView loadRequest:[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"https://iosgods.cn/index.php?/clients/credit/"]]];
        }
       [window addSubview:webView];
    });
}


//功能●●●●●●●●



- (BOOL)Luntan
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"aaaaaaaaaaaaaa");
        UIWindow    *window =   [[UIApplication sharedApplication] keyWindow];
        WKWebView   *webView    =   [[WKWebView alloc] initWithFrame:window.bounds];
        webView.navigationDelegate  =   [JD sharedInstance];
       
        NSString    *udid   =   [[UIDevice currentDevice] identifierForVendor].UUIDString;
        if ([[LRKeychain getKeychainDataForKey:MUFENGKEY] isEqualToString:udid])
        {
            [webView loadRequest:[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"https://iosgods.cn"]]];
        }else
        {
            [webView loadRequest:[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:@"https://iosgods.cn"]]];
        }
        [window addSubview:webView];
    });
        
//第二种验证方式论坛验证结束======================
        
    }


- (BOOL)Bsphp
{
           
    
    NSString * strmutualkey = NULL;
    strmutualkey  = [DES3Utill decrypt:LD_KEY gkey:LD_AAAA];
    NSString * strhost = NULL;
    strhost  = [DES3Utill decrypt:LD_API gkey:LD_AAAA];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^
                   {
                       if([[NSUserDefaults standardUserDefaults] objectForKey:@"activationDeviceID"] != nil)
                       {
                           NSMutableDictionary *param = [NSMutableDictionary dictionary];
                           param[@"api"] = @"login.ic";
                           NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
                           [dateFormatter setDateFormat:@"yyyy-MM-dd#HH:mm:ss"];
                           NSString *dateStr = [dateFormatter stringFromDate:[NSDate date]];
                           param[@"BSphpSeSsL"] = [dateStr MD5Digest];
                           NSDate *date = [NSDate date];
                           NSTimeZone * zone = [NSTimeZone systemTimeZone];
                           NSInteger interval = [zone secondsFromGMTForDate:date];
                           NSDate * nowDate = [date dateByAddingTimeInterval:interval];
                           NSString *nowDateStr = [[nowDate description] stringByReplacingOccurrencesOfString:@" +0000" withString:@""];
                           param[@"date"] = nowDateStr;
                           param[@"md5"] = @"";
                           param[@"mutualkey"] = strmutualkey;
                           param[@"icid"] = [[NSUserDefaults standardUserDefaults] objectForKey:@"activationDeviceID"];
                           param[@"icpwd"] = @"";
                           param[@"key"] = [[VerifyEntry MySharedInstance] getIDFA];
                           param[@"maxoror"] = [[VerifyEntry MySharedInstance] getIDFA];
                           [NetTool Post_AppendURL:strhost myparameters:param mysuccess:^(id responseObject)
                            {
                                NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject
                                                                                     options:NSJSONReadingMutableContainers
                                                                                       error:nil];
                                if (dict)
                                {
                                    NSString *dataString = dict[@"response"][@"data"];
                                    NSRange range = [dataString rangeOfString:@"|1081|"];
                                         
                                    
                                    if (range.location != NSNotFound)
                                    {
                                        UserInfoManager *manager =   [UserInfoManager shareUserInfoManager];
                                        NSArray *arr = [dataString componentsSeparatedByString:@"|"];
                                        [NSObject VPNtishitiao];
                                        
                                        {
                                            manager.state01 = arr[0];
                                            manager.state1081 = arr[1];
                                            manager.deviceID = arr[2];
                                            manager.returnData = arr[3];
                                            manager.expirationTime = arr[4];
                                            manager.activationTime = arr[5];
                                            
                                           
                                            if(manager.deviceID != [[VerifyEntry MySharedInstance] getIDFA])
                                            {
                                                
                                                
                                                manager.state01 = nil;
                                                manager.state1081 = nil;
                                                manager.deviceID = nil;
                                                manager.returnData = nil;
                                                manager.expirationTime = nil;
                                                manager.activationTime = nil;
                                                //已经有卡密没到期
                                                
                                                DisPatchGetMainQueueBegin();
                                                NSString *showMsg = [NSString stringWithFormat:@"过期时间: %@", arr[4]];
                                                SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
                                                [alert addTimerToButtonIndex:0 reverse:YES];
                                                [alert addButton:@"确定" actionBlock:^{
                                                   [NSObject Banben321];
                                                }];
                                                [alert showInfo:@"验证成功" subTitle:showMsg closeButtonTitle:nil duration:0.0f];
                                                DisPatchGetMainQueueEnd();
                                                
                                                
                                            }
                                        }
                                    }
                                    else
                                    {
                                        UserInfoManager *manager =   [UserInfoManager shareUserInfoManager];
                                        manager.state01 = nil;
                                        manager.state1081 = nil;
                                        manager.deviceID = nil;
                                        manager.returnData = nil;
                                        manager.expirationTime = nil;
                                        manager.activationTime = nil;
                                        
                                        //到期返回激活
                                        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^
                                                       {
                                                           [[VerifyEntry MySharedInstance] processActivate];
                                            
                                                       });
                                    }
                                }
                            } myfailure:^(NSError *error)
                            {
                                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^
                                               {
                                                   [[VerifyEntry MySharedInstance] processActivate];
                                               });
                            }];
                       }
                       else
                       {
                           dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^
                                          {
                                              [[VerifyEntry MySharedInstance] processActivate];
                              
                                          });
                       }
                   });
}

@end




